<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePackagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->integer('price')->nullable(); 
            $table->integer('ram')->nullable(); 
            $table->integer('cpu')->nullable();
            $table->integer('disk')->nullable(); 
            $table->integer('slots')->nullable(); 
            $table->integer('databases')->nullable(); 
            $table->integer('backups')->nullable(); 
            $table->integer('ports')->nullable(); 
            $table->string('image')->nullable(); 
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('packages');
    }
}
