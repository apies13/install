<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class DefaultResourcesSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('default_resources')->insert([
            ['key' => 'ram', 'value' => 1024],
            ['key' => 'cpu', 'value' => 100],
            ['key' => 'disk', 'value' => 2048],
            ['key' => 'ports', 'value' => 2],
            ['key' => 'databases', 'value' => 2],
            ['key' => 'backups', 'value' => 2],
            ['key' => 'slots', 'value' => 1],
            ['key' => 'renewal_cost', 'value' => 0],
            
        ]);
    }
}
