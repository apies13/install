<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EggsTableSeeder extends Seeder
{
    /**
     * Seed the eggs table.
     *
     * @return void
     */
    public function run(): void
    {
        DB::table('eggs')->insert([
            ['egg_id' => 4, 'nest_id' => 1, 'name' => 'Paper', 'description' => 'High performance Spigot fork that aims to fix gameplay and mechanics inconsistencies.', 'image' => 'path/to/paper_image.jpg'],
            ['egg_id' => 1, 'nest_id' => 1, 'name' => 'Bungeecord', 'description' => 'For a long time, Minecraft server owners have had a dream that encompasses a free, easy, and reliable way to connect multiple Minecraft servers together. BungeeCord is the answer to said dream. Whether you are a small server wishing to string multiple game-modes together, or the owner of the ShotBow Network, BungeeCord is the ideal solution for you. With the help of BungeeCord, you will be able to unlock your community\'s full potential.', 'image' => 'path/to/bungeecord_image.jpg'],
            ['egg_id' => 3, 'nest_id' => 5, 'name' => 'Vanilla Minecraft', 'description' => 'Minecraft is a game about placing blocks and going on adventures. Explore randomly generated worlds and build amazing things from the simplest of homes to the grandest of castles. Play in Creative Mode with unlimited resources or mine deep in Survival Mode, crafting weapons and armor to fend off dangerous mobs. Do all this alone or with friends.', 'image' => 'path/to/vanilla_minecraft_image.jpg'],
            ['egg_id' => 15, 'nest_id' => 1, 'name' => 'Fabric', 'description' => 'Fabric is a modular modding toolchain targeting Minecraft 1.14 and above, including snapshots.', 'image' => 'path/to/fabric_image.jpg'],
            ['egg_id' => 5, 'nest_id' => 1, 'name' => 'Forge Minecraft', 'description' => 'Minecraft Forge Server. Minecraft Forge is a modding API (Application Programming Interface), which makes it easier to create mods, and also make sure mods are compatible with each other.', 'image' => 'path/to/forge_minecraft_image.jpg'],
            ['egg_id' => 17, 'nest_id' => 5, 'name' => 'NodeJS', 'description' => 'An egg to host any Website. it also has composer, just specify your packages in the packages box, and it will install the packages when you start the server', 'image' => 'path/to/nodejs_image.jpg'],
            ['egg_id' => 14, 'nest_id' => 4, 'name' => 'Rust', 'description' => 'The only aim in Rust is to survive. To do this you will need to overcome struggles such as hunger, thirst and cold. Build a fire. Build a shelter. Kill animals for meat. Protect yourself from other players, and kill them for meat. Create alliances with other players and form a town. Do whatever it takes to survive.', 'image' => 'path/to/rust_image.jpg'],
            ['egg_id' => 19, 'nest_id' => 5, 'name' => 'FiveM', 'description' => 'A new FiveM egg for the latest builds due to recent changes in FiveM', 'image' => 'path/to/fivem_image.jpg'],
            ['egg_id' => 20, 'nest_id' => 5, 'name' => 'Bedrock', 'description' => 'Bedrock Edition (also known as the Bedrock Version, Bedrock Codebase, Bedrock Engine or just Bedrock) ', 'image' => 'path/to/bedrock_image.jpg'],
        ]);
    }
}
