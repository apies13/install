<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Package;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;
use Illuminate\Support\Facades\Log;

class MarketPlaceController extends Controller
{
    public function index()
    {
        $products = Package::select('id', 'title', 'ram', 'cpu', 'disk', 'slots', 'databases', 'backups', 'ports', 'price', 'image')->get();
        return view('market', compact('products'));
    }

    public function purchase(Request $request, $id)
    {
        $user = Auth::user();
        $package = Package::findOrFail($id);

        // Check if the user has enough credits
        if ($user->credits < $package->price) {
            session()->flash('notification', [
                'type' => 'error',
                'icon' => 'error',
                'title' => 'Purchase Failed',
                'text' => 'You do not have enough credits to purchase this package.',
            ]);

            return redirect()->back();
        }

        // Deduct credits and add package resources to the user
        $user->credits -= $package->price;
        $user->ram += $package->ram;
        $user->cpu += $package->cpu;
        $user->disk += $package->disk;
        $user->slots += $package->slots;
        $user->ports += $package->ports;
        $user->backups += $package->backups;
        $user->databases += $package->databases;
        $user->save();

        // Log the purchase in the database
        DB::table('purchased-packages')->insert([
            'user_id' => $user->id,
            'package_id' => $package->id,
            'price' => $package->price,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        // Flash success notification to the user
        session()->flash('notification', [
            'type' => 'success',
            'icon' => 'success',
            'title' => 'Purchase Completed',
            'text' => 'Package purchased successfully and settings updated!',
        ]);

        // Send Discord notification
        $this->sendDiscordPurchaseNotification($user, $package);

        return redirect()->back();
    }

    protected function sendDiscordPurchaseNotification($user, $package)
    {
        $client = new Client();
        $embed = [
            'embeds' => [[
                'title' => '🎉 Package Purchase Successful',
                'color' => 65280, // Green for success
                'fields' => [
                    [
                        'name' => 'User',
                        'value' => $user->name . ' (ID: ' . $user->id . ')',
                        'inline' => true,
                    ],
                    [
                        'name' => 'Package Purchased',
                        'value' => $package->title, // Changed to `title` from `package_name`
                        'inline' => true,
                    ],
                    [
                        'name' => 'Price',
                        'value' => $package->price . ' credits',
                        'inline' => true,
                    ],
                    [
                        'name' => 'New Credits Balance',
                        'value' => $user->credits . ' credits',
                        'inline' => true,
                    ],
                ],
                'footer' => [
                    'text' => 'Purchase completed at ' . now()->toDateTimeString(),
                ],
                'timestamp' => now()->toISOString(), // Proper timestamp formatting
            ]]
        ];

        // Log the payload for debugging
        Log::info('Sending Discord embed:', $embed);

        try {
            $client->post(config('services.webhook.webhook_url'), [
                'json' => $embed,
                'headers' => [
                    'Content-Type' => 'application/json',
                ],
            ]);
        } catch (RequestException $e) {
            Log::error('Discord webhook request failed: ' . $e->getMessage());
        }
    }
}
