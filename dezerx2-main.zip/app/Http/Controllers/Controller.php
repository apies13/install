<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;

abstract class Controller
{
    protected $pterodactylApiBase;
    protected $pterodactylClientApiKey;

    public function __construct()
    {
        $this->pterodactylApiBase = env('PTERODACTYL_API_URL');
        $this->pterodactylClientApiKey = env('PTERODACTYL_CLIENT_KEY');
    }

    protected function getServerDetails($identifier)
    {
        $username = auth()->user()->name;
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
        ])->get($url);
        if ($response->successful()) {
            $serverData = $response->json('attributes', []);
            $defaultAllocation = collect($serverData['relationships']['allocations']['data'] ?? [])
                ->first(fn($allocation) => $allocation['attributes']['is_default'] ?? false);
            return [
                'name' => $serverData['name'] ?? 'Unknown',
                'identifier' => $identifier,
                'username' => $username,
                'description' => $serverData['description'] ?? 'No description',
                'limits' => $serverData['limits'] ?? [],
                'sftp' => $serverData['sftp_details'] ?? [],
                'ip' => $defaultAllocation
                    ? $defaultAllocation['attributes']['ip_alias'] . ':' . $defaultAllocation['attributes']['port']
                    : 'No IP',
            ];
        }
        return null;
    }
    
}
