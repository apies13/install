<?php

namespace App\Http\Controllers\Providers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Http\Controllers\CreateUserController;

class DiscordController extends Controller
{
    public function redirect()
    {
        return Socialite::driver('discord')->redirect();
    }

    public function callback(Request $request)
    {
        $discordUser = Socialite::driver('discord')->user();
        $user = User::where('discord_id', $discordUser->getId())->first();
    
        $resources = \DB::table('default_resources')->pluck('value', 'key')->toArray();
    
        $ram = $resources['ram'] ?? 1024;
        $cpu = $resources['cpu'] ?? 100;
        $disk = $resources['disk'] ?? 2048;
        $slots = $resources['slots'] ?? 1;
        $databases = $resources['databases'] ?? 1;
        $ports = $resources['ports'] ?? 1;
        $backups = $resources['backups'] ?? 1;
    
        $discordName = strtolower($discordUser->getName());
        $discordName = str_replace(' ', '', $discordName);
               
        if (!$user) {
            $user = User::create([
                'name' => $discordName,
                'email' => $discordUser->getEmail(),
                'discord_id' => $discordUser->getId(),
                'avatar' => $discordUser->getAvatar(),
                'ram' => $ram,
                'cpu' => $cpu,
                'disk' => $disk,
                'slots' => $slots,
                'databases' => $databases,
                'ports' => $ports,
                'backups' => $backups,
                'email_verified_at' => now(),
            ]);
        } else {
            $user->name = $discordName;
            $user->save();
        }
    
        $pterodactylController = new CreateUserController();
        $pterodactylUserId = $pterodactylController->createUser(
            $discordUser->getEmail(),
            $discordName
        );
    
        if ($pterodactylUserId) {
            $user->pterodactyl_user_id = $pterodactylUserId;
            $user->save();
        }
    
        Auth::login($user);
        return redirect()->intended('/dashboard');
    }
    

}
