<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Package;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class ProductController extends Controller
{
    public function create()
    {
        $activeProducts = Package::all(); 
        return view('admin.create-product', compact('activeProducts'));
    }
    
    public function destroy($id)
    {
        $product = Package::findOrFail($id);
        $product->delete();
    
        return redirect()->route('admin.products.create')->with('success', 'Product deleted successfully.');
    }
    
    public function store(Request $request)
    {
        Log::info('Store Product Request:', $request->all());
        $request->validate([
            'title' => 'required|string|max:255',
            'price' => 'required|integer|min:0',
            'ram' => 'required|integer|min:0',
            'cpu' => 'required|integer|min:0',
            'disk' => 'required|integer|min:0',
            'slots' => 'required|integer|min:0',
            'databases' => 'required|integer|min:0',
            'ports' => 'required|integer|min:0',
            'backups' => 'required|integer|min:0',
            'image' => 'required|url',  
        ]);

        $package = new Package();
        $package->title = $request->input('title');
        $package->price = $request->input('price');
        $package->ram = $request->input('ram');
        $package->cpu = $request->input('cpu');
        $package->disk = $request->input('disk');
        $package->slots = $request->input('slots');
        $package->databases = $request->input('databases');
        $package->ports = $request->input('ports');
        $package->backups = $request->input('backups');
        $package->image = $request->input('image');
        $package->save();
        Log::info('Product created successfully:', ['package_id' => $package->id, 'title' => $package->title]);
        return redirect()->route('admin.products.create')->with('success', 'Product created successfully.');
    }
}
