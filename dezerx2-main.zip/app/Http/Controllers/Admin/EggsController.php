<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\Egg;

class EggsController extends Controller
{
    public function index()
    {
        $eggs = Egg::all();
        return view('admin.eggs', ['eggs' => $eggs]);
    }
    public function destroy($id)
    {
        $egg = Egg::findOrFail($id);
        $egg->delete();

        return redirect()->route('admin.eggs')->with('success', 'Egg deleted successfully');
    }
    public function update(Request $request, $id)
{
    $egg = Egg::findOrFail($id);
    $egg->update($request->only(['egg_id', 'name', 'description', 'image', 'nest_id']));

    return redirect()->back()->with('success', 'Egg updated successfully');
}

public function store(Request $request)
{
    $validated = $request->validate([
        'name' => 'required|string|max:255',
        'description' => 'required|string',
        'egg_id' => 'required|integer', 
        'nest_id' => 'required|integer', 
    ]);

    try {
        DB::table('eggs')->insert([
            'name' => $validated['name'],
            'description' => $validated['description'],
            'egg_id' => $validated['egg_id'],
            'nest_id' => $validated['nest_id'],
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Log::info('Egg created successfully', [
            'egg_data' => $validated,
        ]);

        return redirect()->route('admin.eggs')->with('success', 'Egg created successfully');
    } catch (\Exception $e) {
        Log::error('Failed to create Egg', [
            'exception' => $e->getMessage(),
            'egg_data' => $validated,
        ]);

        return redirect()->route('admin.eggs')->with('error', 'Failed to create Egg');
    }
}
};