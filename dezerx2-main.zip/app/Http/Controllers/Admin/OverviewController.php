<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use GuzzleHttp\Client;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Models\Egg;

class OverviewController extends Controller
{
    public function index()
    {
        $resources = \DB::table('default_resources')->pluck('value', 'key')->toArray();
        $userCount = User::count();
        $ram = $resources['ram'] ?? 1024;
        $cpu = $resources['cpu'] ?? 100;
        $disk = $resources['disk'] ?? 2048;
        $slots = $resources['slots'] ?? 1;
        $databases = $resources['databases'] ?? 1;
        $ports = $resources['ports'] ?? 1;
        $backups = $resources['backups'] ?? 1;

        return view('admin.dashboard', compact('ram', 'cpu', 'disk', 'slots', 'databases', 'ports', 'backups', 'userCount'));
    }

    public function updateDefaultResources(Request $request)
    {
        $validated = $request->validate([
            'default_ram' => 'required|integer|min:1',
            'default_cpu' => 'required|integer|min:1',
            'default_disk' => 'required|integer|min:1',
            'default_slots' => 'required|integer|min:1',
            'default_ports' => 'required|string|max:255',
            'default_databases' => 'required|string',
            'default_backups' => 'nullable|string|max:255',
            'renewal' => 'nullable|string|max:255',
        ]);

        DB::table('default_resources')->updateOrInsert(
            ['key' => 'ram'],
            ['value' => $validated['default_ram']]
        );
        DB::table('default_resources')->updateOrInsert(
            ['key' => 'cpu'],
            ['value' => $validated['default_cpu']]
        );
        DB::table('default_resources')->updateOrInsert(
            ['key' => 'disk'],
            ['value' => $validated['default_disk']]
        );
        DB::table('default_resources')->updateOrInsert(
            ['key' => 'slots'],
            ['value' => $validated['default_slots']]
        );
        DB::table('default_resources')->updateOrInsert(
            ['key' => 'ports'],
            ['value' => $validated['default_ports']]
        );
        DB::table('default_resources')->updateOrInsert(
            ['key' => 'databases'],
            ['value' => $validated['default_databases']]
        );
        DB::table('default_resources')->updateOrInsert(
            ['key' => 'backups'],
            ['value' => $validated['default_backups']]
        );
        DB::table('default_resources')->updateOrInsert(
            ['key' => 'renewal_cost'],
            ['value' => $validated['renewal']]
        );

        return redirect()->route('admin.dashboard')->with('success', 'Settings updated successfully.');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'location_id' => 'required|integer|unique:locations,location_id',
            'location_name' => 'required|string|max:255',
            'fee' => 'required|integer|min:0',
        ]);

        DB::table('locations')->insert([
            'location_id' => $validated['location_id'],
            'location_name' => $validated['location_name'],
            'fee' => $validated['fee'],
        ]);

        return redirect()->route('admin.dashboard')->with('success', 'Location added successfully.');
    }
    public function ads(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'required|string|max:255',
            'logo_url' => 'required|string|max:255',
            'website' => 'required|string|max:255',
        ]);

        $ad = DB::table('ads')->first();

        if ($ad) {
            DB::table('ads')->where('id', $ad->id)->update([
                'name' => $validated['name'],
                'description' => $validated['description'],
                'website' => $validated['website'],
                'logo_url' => $validated['logo_url'],
                'updated_at' => now(),
            ]);

            return redirect()->route('admin.settings')->with('success', 'Ad updated successfully.');
        } else {
            DB::table('ads')->insert([
                'name' => $validated['name'],
                'description' => $validated['description'],
                'website' => $validated['website'],
                'logo_url' => $validated['logo_url'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return redirect()->route('admin.settings')->with('success', 'Ad added successfully.');
        }
    }


    public function coupons(Request $request)
    {
        $validated = $request->validate([
            'ram' => 'nullable|integer|min:0',
            'cpu' => 'nullable|integer|min:0',
            'disk' => 'nullable|integer|min:0',
            'credits' => 'nullable|integer|min:0',
            'slots' => 'nullable|integer|min:0',
            'databases' => 'nullable|integer|min:0',
            'ports' => 'nullable|integer|min:0',
            'backups' => 'nullable|integer|min:0',
            'name' => 'required|string|max:255',
            'uses' => 'required|integer|min:0',
        ]);

        DB::table('coupons')->insert([
            'ram' => $validated['ram'],
            'cpu' => $validated['cpu'],
            'disk' => $validated['disk'],
            'credits' => $validated['credits'],
            'slots' => $validated['slots'],
            'databases' => $validated['databases'],
            'ports' => $validated['ports'],
            'backups' => $validated['backups'],
            'coupon_name' => $validated['name'],
            'uses' => $validated['uses'],
        ]);

        return redirect()->route('admin.settings')->with('success', 'Coupon added successfully.');
    }

    public function users()
    {
        $users = User::all();
        $userData = $users->map(function ($user) {
            return [
                'id' => $user->id,
                'name' => $user->name,
                'role' => $user->role === 'admin' ? 'admin' : 'user',
                'email' => $user->email,
                'credits' => $user->credits,
            ];
        });
        return view('admin.users', ['users' => $userData]);
    }
    public function updateCredits(Request $request, $id)
    {
        $request->validate([
            'credits' => 'required|numeric|min:0',
        ]);

        $user = User::findOrFail($id);
        $user->credits = $request->input('credits');
        $user->save();

        return redirect()->back()->with('success', 'Credits updated successfully.');
    }
    public function deleteUser($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->back()->with('success', 'User deleted successfully.');
    }



    public function deleteUsers($id)
    {
        $client = new Client([
            'base_uri' => env('PTERODACTYL_API_URL'),
            'headers' => [
                'Authorization' => 'Bearer ' . env('PTERODACTYL_API_KEY'),
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'verify' => true,
        ]);

        try {
            $response = $client->delete("/api/application/users/{$id}");

            if ($response->getStatusCode() == 204) {
                return redirect()->route('admin.users')->with('success', 'Server deleted successfully.');
            }

            return redirect()->route('admin.users')->with('error', 'Failed to delete user.');
        } catch (\Exception $e) {
            return redirect()->route('admin.users')->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    public function settings()
    {
        return view('admin.settings');
    }

    public function filterServers(Request $request)
    {
        $request->validate([
            'keyword' => 'required|string|max:255',
        ]);

        $keyword = $request->input('keyword');

        $client = new Client([
            'base_uri' => env('PTERODACTYL_API_URL'),
            'headers' => [
                'Authorization' => 'Bearer ' . env('PTERODACTYL_API_KEY'),
                'Accept' => 'application/json',
            ],
        ]);

        try {
            $response = $client->get('/api/application/servers');
            $servers = json_decode($response->getBody()->getContents(), true);

            $allServers = array_map(function ($server) {
                return [
                    'id' => $server['attributes']['id'],
                    'name' => $server['attributes']['name'],
                ];
            }, $servers['data']);
            Log::info('Fetched Servers (ID and Name):', $allServers);

            $filteredServers = array_filter($servers['data'], function ($server) use ($keyword) {
                return stripos($server['attributes']['name'], $keyword) !== false;
            });

            $nonFilteredServers = array_filter($servers['data'], function ($server) use ($keyword) {
                return stripos($server['attributes']['name'], $keyword) === false;
            });

            $filteredServerDetails = array_map(function ($server) {
                return [
                    'id' => $server['attributes']['id'],
                    'name' => $server['attributes']['name'],
                ];
            }, $filteredServers);
            Log::info('Filtered Servers (ID and Name):', $filteredServerDetails);

            $nonFilteredServerDetails = array_map(function ($server) {
                return [
                    'id' => $server['attributes']['id'],
                    'name' => $server['attributes']['name'],
                ];
            }, $nonFilteredServers);
            Log::info('Non-Filtered Servers (ID and Name):', $nonFilteredServerDetails);

            $deletedCount = 0;
            foreach ($nonFilteredServers as $server) {
                $serverId = $server['attributes']['id'];
                try {
                    $client->delete("/api/application/servers/{$serverId}");
                    Log::info('Deleted Server:', ['id' => $serverId, 'name' => $server['attributes']['name']]);
                    $deletedCount++;
                } catch (\Exception $e) {
                    Log::error('Error deleting server ' . $serverId . ': ' . $e->getMessage());
                }
            }

            return view('admin.filtered-servers', [
                'filteredServers' => $filteredServers,
                'nonFilteredServers' => $nonFilteredServers,
                'deletedCount' => $deletedCount
            ]);
        } catch (\Exception $e) {
            Log::error('Error fetching or filtering servers: ' . $e->getMessage());
            return back()->withErrors('An error occurred while fetching servers.');
        }
    }


    public function servers()
    {
        $servers = DB::table('servers')->get();
        return view('admin.servers', ['servers' => $servers]);
    }


}
