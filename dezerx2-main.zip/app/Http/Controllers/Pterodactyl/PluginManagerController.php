<?php

namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class PluginManagerController extends Controller
{

// Show Plugins Method
public function showPlugins(Request $request, $identifier)
{
    $serverDetails = $this->getServerDetails($identifier);
    $page = $request->query('page', 1); 
    $plugins = $this->getSpigetPlugins($page);
    return view('server.plugin-manager', [
        'serverDetails' => $serverDetails,
        'plugins' => $plugins,
        'currentPage' => $page,
        'identifier' => $identifier,

    ]);
}




    //Get Spiget Plugins 
    
    private function getSpigetPlugins($page = 1)
    {
        $url = "https://api.spiget.org/v2/resources/free?size=20&page={$page}";
        $response = Http::withHeaders([
            'Accept' => 'application/json',
        ])
          ->get($url);
    
        if ($response->successful()) {
            $plugins = $response->json();
            $pluginsWithIcon = array_filter($plugins, function ($plugin) {
                return !empty($plugin['icon']['url']);
            });
            usort($pluginsWithIcon, function ($a, $b) {
                return strcmp($a['icon']['url'], $b['icon']['url']);
            });
            $pluginsWithoutIcon = array_filter($plugins, function ($plugin) {
                return empty($plugin['icon']['url']);
            });
            $sortedPlugins = array_merge($pluginsWithIcon, $pluginsWithoutIcon);
    
            return $sortedPlugins;
        } else {
            Log::warning('Failed to retrieve plugins from Spiget', [
                'status' => $response->status(),
                'response_body' => $response->body()
            ]);
            return [];
        }
    }
    



    // Search Plugins

    public function searchPlugins(Request $request, $identifier)
    {
        $query = $request->input('query', '');
        $plugins = [];
        $serverDetails = $this->getServerDetails($identifier);
        $page = $request->query('page', 1); 
        if (!empty($query)) {
            $url = "https://api.spiget.org/v2/search/resources/" . urlencode($query) . "?field=name";
            $response = Http::withHeaders([
                'Accept' => 'application/json',
            ])
            ->get($url);
    
            if ($response->successful()) {
                $plugins = $response->json();
            } else {
                Log::warning('Failed to search plugins from Spiget', [
                    'status' => $response->status(),
                    'response_body' => $response->body()
                ]);
            }
        }
        return view('server.plugin-manager', [
            'serverDetails' => $serverDetails,
            'plugins' => $plugins,
            'currentPage' => $page,
            'identifier' => $identifier
        ]);
    }
   



    // Download Plugins 

    public function downloadPlugin(Request $request, $identifier)
{
    $pluginId = $request->input('pid');
    $pluginName = $request->input('name');
    if (!$pluginId) {
        return redirect()->back()->with('error', 'Plugin ID is missing.');
    }
    if (!$pluginName) {
        return redirect()->back()->with('error', 'Plugin name is missing.');
    }
    $url = "https://api.spiget.org/v2/resources/{$pluginId}/download";
    $response = Http::withHeaders([
        'Accept' => 'application/json',
    ])->get($url);
    if ($response->successful()) {
        $path = storage_path('app/plugins/' . $pluginName . '.jar');
        if (!file_exists(dirname($path))) {
            mkdir(dirname($path), 0755, true);
        }
        file_put_contents($path, $response->body());
        $uploadResponse = $this->uploadFiles($path, $identifier);
        if ($uploadResponse->status() === 'success') {
            return redirect()->back()->with('success', 'Plugin downloaded and uploaded successfully.');
        } else {
            return redirect()->back()->with('error', 'Plugin downloaded but failed to upload.');
        }
    } else {
        return redirect()->back()->with('error', 'Failed to download plugin. Please check the plugin ID or try again later.');
    }
}


    
    
    

// Upload Files Function
public function uploadFiles($filePath, $identifier)
{
    $server = $this->getServerDetails($identifier);
    $pteroUrl = $this->pterodactylApiBase;
    $pteroApiKey = $this->pterodactylClientApiKey;
    $currentDirectory = 'plugins';
    if (!file_exists($filePath)) {
        return response()->json(['status' => 'error'], 404);
    }
    $backendDirectory = $currentDirectory ? trim($currentDirectory, '/') : '';
    try {
        $response = Http::withHeaders([
            'Authorization' => "Bearer {$pteroApiKey}",
            'Accept' => 'application/json',
        ])
          ->get("{$pteroUrl}/api/client/servers/{$identifier}/files/upload");

        if ($response->successful()) {
            $responseData = $response->json();
            $uploadUrl = data_get($responseData, 'attributes.url');
            $queryParams = [];
            parse_str(parse_url($uploadUrl, PHP_URL_QUERY), $queryParams);
            $token = $queryParams['token'] ?? '';

            if ($uploadUrl && $token) {
                $uploadUrlWithDirectory = $uploadUrl . (parse_url($uploadUrl, PHP_URL_QUERY) ? '&' : '?') . http_build_query(['directory' => $backendDirectory]);

                $uploadResponse = Http::withHeaders([
                    'Authorization' => "Bearer {$token}",
                ])
                  ->attach('files', file_get_contents($filePath), basename($filePath))
                  ->post($uploadUrlWithDirectory);

                if ($uploadResponse->successful()) {
                    return response()->json(['status' => 'success']);
                } else {
                    return response()->json(['status' => 'error'], $uploadResponse->status());
                }
            } else {
                return response()->json(['status' => 'error'], 500);
            }
        } else {
            return response()->json(['status' => 'error'], $response->status());
        }
    } catch (\Exception $e) {
        return response()->json(['status' => 'error'], 500);
    }
} 
    
}
