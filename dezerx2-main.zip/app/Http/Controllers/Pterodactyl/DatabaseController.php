<?php

namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class DatabaseController extends Controller
{
    public function index($identifier)
    {
        return view('server.database', [
            'serverDetails' => $this->getServerDetails($identifier),
            'identifier' => $identifier,
            'databases' => $this->getDatabases($identifier)
        ]); 
       }
       
       private function getDatabases($identifier)
       {
           $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/databases?include=password";  
           $response = Http::withHeaders([
               'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
               'Accept' => 'application/json',
           ])->get($url);
       
           if ($response->successful()) {
               return collect($response->json()['data'] ?? [])->map(function ($database) {
                   return [
                       'host' => $database['attributes']['host']['address'] ?? 'Unknown',
                       'port' => $database['attributes']['host']['port'] ?? 'Unknown',
                       'name' => $database['attributes']['name'] ?? 'Unnamed Database',
                       'username' => $database['attributes']['username'] ?? 'Unknown',
                       'password' => $database['attributes']['relationships']['password']['attributes']['password'] ?? 'Unknown',
                       'connections_from' => $database['attributes']['connections_from'] ?? 'Unknown',
                       'max_connections' => $database['attributes']['max_connections'] ?? 'Unknown',
                   ];
               });
           }
       
           return [];
       }



       public function createDatabase(Request $request, $identifier)
       {
           $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/databases";
           $response = Http::withHeaders([
               'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
               'Accept' => 'application/json',
               'Content-Type' => 'application/json',
           ])->post($url, [
               'database' => $this->generateBackupName(),
               'remote' => "%",
           ]);
       
           if ($response->successful()) {
               return redirect()->back()->with('status', 'Database created successfully!');
           } else {
               return redirect()->back()->withErrors('Failed to create Database.');
           }
       }
       
   
       private function generateBackupName()
       {
           return 'dezer-' . bin2hex(random_bytes(4)); 
       }
       
}
