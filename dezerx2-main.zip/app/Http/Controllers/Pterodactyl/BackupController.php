<?php

namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class BackupController extends Controller
{
    public function showBackups(Request $request, $identifier)
    {
        return view('server.backup', [
            'serverDetails' => $this->getServerDetails($identifier),
            'identifier' => $identifier,
            'backups' => $this->getBackups($identifier),
        ]);
    }

    private function getBackups($identifier)
    {
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/backups";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
        ])->withoutVerifying()->get($url);

        if ($response->successful()) {
            return collect($response->json()['data'] ?? [])->map(function ($backup) {
                return [
                    'name' => $backup['attributes']['name'] ?? 'Unnamed Backup',
                    'bytes' => $backup['attributes']['bytes'] ?? 'Unknown',
                    'created' => $backup['attributes']['created_at'] ?? 'Unknown',
                    'uuid' => $backup['attributes']['uuid'] ?? 'Unknown',
                ];
            });
        }

        return [];
    }

    public function createBackup(Request $request, $identifier)
    {
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/backups";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->withoutVerifying()->post($url, [
            'name' => $this->generateBackupName(),
        ]);

        if ($response->successful()) {
            return redirect()->back()->with('status', 'Backup created successfully!');
        } else {
            return redirect()->back()->withErrors('Failed to create backup.');
        }
    }

    private function generateBackupName()
    {
        return 'dezer-' . bin2hex(random_bytes(4)); 
    }

    public function deleteBackup(Request $request, $identifier, $backupUuid)
    {
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/backups/{$backupUuid}";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
        ])->delete($url);

        return $response->successful()
        ? redirect()->back()->with('success', 'Backup deleted successfully!')
        : redirect()->back()->with('error', 'Failed to delete backup.');
    }

    public function downloadBackup(Request $request, $identifier, $backupUuid)
    {
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/backups/{$backupUuid}/download";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
        ])->get($url);

        if ($response->successful()) {
            $signedUrl = $response->json()['attributes']['url'] ?? null;
            return $signedUrl ? redirect($signedUrl) : redirect()->back()->with('error', 'Failed to retrieve download URL.');
        }

        return redirect()->back()->with('error', 'Failed to retrieve download URL.');
    }
}
