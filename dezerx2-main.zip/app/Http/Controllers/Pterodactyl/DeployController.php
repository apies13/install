<?php

namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\Server; // Import the Server model

class DeployController extends Controller
{
    protected $apiUrl;
    protected $apiKey;

    public function __construct()
    {
        $this->apiUrl = env('PTERODACTYL_API_URL');
        $this->apiKey = env('PTERODACTYL_API_KEY');
    }

    public function index()
    {
        $user = auth()->user();
        $locations = DB::table('locations')->get();
        $nests = $this->fetchNests();
        return view('deploy', compact('locations', 'nests'));
    }

    public function fetchNests()
    {
        $url = $this->apiUrl . '/api/application/nests';
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Accept' => 'application/json',
        ])->withOptions([
            'verify' => false,
        ])->get($url);

        if ($response->successful()) {
            $nests = $response->json()['data'];
            $filteredNests = array_filter($nests, function ($nest) {
                return $nest['attributes']['id'] == 1;
            });

            return array_values($filteredNests);
        } else {
            Log::error('Failed to fetch nests from Pterodactyl API', ['response' => $response->body()]);
            throw new \Exception('Failed to fetch nests');
        }
    }

    public function fetchEggs($nestId)
    {
        $url = $this->apiUrl . "/api/application/nests/{$nestId}/eggs";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Accept' => 'application/json',
        ])->withOptions([
            'verify' => false,
        ])->get($url);

        if ($response->successful()) {
            return $response->json()['data'];
        } else {
            Log::error('Failed to fetch eggs from Pterodactyl API', ['response' => $response->body()]);
            throw new \Exception('Failed to fetch eggs');
        }
    }

    public function fetchEggDetails($nestId, $eggId)
    {
        $url = $this->apiUrl . "/api/application/nests/{$nestId}/eggs/{$eggId}";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Accept' => 'application/json',
        ])->withOptions([
            'verify' => false,
        ])->get($url);

        if ($response->successful()) {
            $responseData = $response->json();
            if (isset($responseData['attributes']['docker_image'])) {
                return $responseData['attributes']['docker_image'];
            } else {
                Log::error('Docker image not found in egg details', ['response' => $responseData]);
                throw new \Exception('Docker image not found');
            }
        } else {
            Log::error('Failed to fetch egg details from Pterodactyl API', ['response' => $response->body()]);
            throw new \Exception('Failed to fetch egg details');
        }
    }

    public function fetchEggVariables($nestId, $eggId)
    {
        $url = $this->apiUrl . "/api/application/nests/{$nestId}/eggs/{$eggId}?include=variables";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
            'Accept' => 'application/json',
        ])->withOptions([
            'verify' => false,
        ])->get($url);

        Log::info('Fetch Egg Variables Response', ['response' => $response->body()]);

        if ($response->successful()) {
            $responseData = $response->json();
            Log::info('Parsed Response Data', ['data' => $responseData]);

            if (isset($responseData['attributes']['relationships']['variables']['data'])) {
                return $responseData['attributes']['relationships']['variables']['data'];
            } else {
                Log::error('Unexpected response format from Pterodactyl API', ['response' => $responseData]);
                throw new \Exception('Unexpected response format');
            }
        } else {
            Log::error('Failed to fetch egg variables from Pterodactyl API', ['response' => $response->body()]);
            throw new \Exception('Failed to fetch egg variables');
        }
    }

    public function createServer(Request $request)
    {
        $user = auth()->user();
        $maxRam = $user->ram;
        $maxCpu = $user->cpu;
        $maxDisk = $user->disk;
        $maxPorts = $user->ports;
        $maxBackups = $user->backups;
        $maxDatabases = $user->databases;

        $slots = $user->slots;
        $userpid = $user->pterodactyl_user_id;

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'nest_id' => 'required|integer',
            'location_id' => 'required|integer',
            'egg_id' => 'required|integer',
            'ram' => 'required|integer|min:1024|max:' . $maxRam,
            'cpu' => 'required|integer|min:100|max:' . $maxCpu,
            'disk' => 'required|integer|min:1024|max:' . $maxDisk,
            'ports' => 'required|integer|min:1|max:' . $maxPorts,
            'databases' => 'required|integer|min:0|max:' . $maxDatabases,
            'backups' => 'required|integer|min:0|max:' . $maxBackups,
        ]);

        $locationId = $validated['location_id'];
        $locationFee = DB::table('locations')->where('location_id', $locationId)->value('fee');

        if ($user->credits >= $locationFee) {
            $user->credits -= $locationFee;
            $user->save();
        } else {
            session()->flash('notification', [
                'icon' => 'error',
                'title' => 'Insufficient Credits',
                'text' => 'You do not have enough credits to select this location.',
            ]);

            return redirect()->back()->withInput();
        }

        if (
            $validated['ram'] > $maxRam ||
            $validated['ports'] > $maxPorts ||
            $validated['backups'] > $maxBackups ||
            $validated['databases'] > $maxDatabases ||
            $validated['cpu'] > $maxCpu ||
            $validated['disk'] > $maxDisk
        ) {
            session()->flash('notification', [
                'icon' => 'error',
                'title' => 'Resource Limits Exceeded',
                'text' => 'The requested resources exceed your available limits. Please adjust the values.',
            ]);

            return redirect()->back()->withInput();
        }

        try {
            $dockerImage = $this->fetchEggDetails($validated['nest_id'], $validated['egg_id']);
            $variablesUrl = $this->apiUrl . "/api/application/nests/{$validated['nest_id']}/eggs/{$validated['egg_id']}?include=variables";
            $variablesResponse = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiKey,
                'Accept' => 'application/json',
            ])->withOptions([
                'verify' => false,
            ])->get($variablesUrl);

            if ($variablesResponse->successful()) {
                $variablesData = $variablesResponse->json();
                $environmentVariables = $variablesData['attributes']['relationships']['variables']['data'];

                $environment = array_filter(array_map(function ($e) {
                    $envVariable = $e['attributes']['env_variable'];
                    $defaultValue = $e['attributes']['default_value'];
                    $rules = $e['attributes']['rules'];

                    if (!str_contains($rules, "nullable")) {
                        return [$envVariable => $defaultValue];
                    }
                    return [];
                }, $environmentVariables));

                $environment = array_merge(...$environment);
                $url = $this->apiUrl . '/api/application/servers';
                $response = Http::withHeaders([
                    'Authorization' => 'Bearer ' . $this->apiKey,
                    'Accept' => 'application/json',
                ])->withOptions([
                    'verify' => false,
                ])->post($url, [
                    'name' => $validated['name'],
                    'description' => $validated['description'],
                    'nest' => $validated['nest_id'],
                    'user' => $userpid,
                    'docker_image' => $dockerImage,
                    'egg' => $validated['egg_id'],
                    'environment' => $environment,
                    'limits' => [
                        'memory' => $validated['ram'],
                        'swap' => 0,
                        'disk' => $validated['disk'],
                        'io' => 500,
                        'cpu' => $validated['cpu'],
                    ],
                    'feature_limits' => [
                        'databases' => $validated['databases'],
                        'allocations' => $validated['ports'],
                        'backups' => $validated['backups'],
                    ],
                    'deploy' => [
                        'locations' => [$locationId],
                        'dedicated_ip' => false,
                        'port_range' => [],
                    ],
                    'start_on_completion' => true,
                    'startup' => 'java -Xms128M -Xmx512M -jar {{SERVER_JARFILE}}',
                ]);

                if ($response->successful()) {

                    $serverID = $response->json('attributes.id');

                    $user->ram -= $validated['ram'];
                    $user->cpu -= $validated['cpu'];
                    $user->disk -= $validated['disk'];
                    $user->ports -= $validated['ports'];
                    $user->databases -= $validated['databases'];
                    $user->backups -= $validated['backups'];

                    $user->slots -= 1;
                    $user->save();

                    session()->flash('notification', [
                        'icon' => 'success',
                        'title' => 'Server Created',
                        'text' => 'Your server has been created successfully!',
                    ]);

                    Server::create([
                        'name' => $validated['name'],
                        'description' => $validated['description'],
                        'user_id' => $user->id,
                        'owner_id' => $serverID,
                        'ram' => $validated['ram'],
                        'cpu' => $validated['cpu'],
                        'disk' => $validated['disk'],
                        'ports' => $validated['ports'],
                        'databases' => $validated['databases'],
                        'backups' => $validated['backups'],
                        'location_id' => $validated['location_id'],
                        'created_at' => now(),
                    ]);

                    return redirect()->route('dashboard');
                } else {
                    Log::error('Failed to create server', ['response' => $response->body()]);

                    session()->flash('notification', [
                        'icon' => 'error',
                        'title' => 'Server Creation Failed',
                        'text' => 'Failed to create the server. Please try again.',
                    ]);

                    return redirect()->back();
                }
            } else {
                Log::error('Failed to fetch environment variables from Pterodactyl API', ['response' => $variablesResponse->body()]);

                session()->flash('notification', [
                    'icon' => 'error',
                    'title' => 'Environment Variables Error',
                    'text' => 'Failed to fetch environment variables. Please try again.',
                ]);

                return redirect()->back();
            }
        } catch (\Exception $e) {
            Log::error('Failed to create server', ['error' => $e->getMessage()]);

            session()->flash('notification', [
                'icon' => 'error',
                'title' => 'Unexpected Error',
                'text' => 'Failed to create server. Please try again.',
            ]);

            return redirect()->back();
        }
    }


}
