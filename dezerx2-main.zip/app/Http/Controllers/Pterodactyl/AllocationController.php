<?php

namespace App\Http\Controllers\Pterodactyl;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AllocationController extends Controller
{

    public function showNetwork(Request $request, $identifier)
    {
        $serverDetails = $this->getServerDetails($identifier);
        $allocations = $this->getAllocations($identifier);
        return view('server.allocations', [
            'serverDetails' => $serverDetails,
            'allocations' => $allocations,
        ]);
    }


    private function getAllocations($identifier)
    {
        $url = "{$this->pterodactylApiBase}/api/client/servers/{$identifier}/network/allocations";
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylClientApiKey,
            'Accept' => 'application/json',
        ])
          ->get($url);
    
        if ($response->successful()) {
            $responseData = $response->json();
            return $responseData['data'] ?? [];
        } else {
            return [];
        }
    }
    
}
