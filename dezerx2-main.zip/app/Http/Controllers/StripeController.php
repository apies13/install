<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Stripe\Stripe;
use Stripe\Checkout\Session as CheckoutSession;

class StripeController extends Controller
{
    public function index()
    {
        $userId = auth()->id();
        $user = DB::table('users')->where('id', $userId)->first();
        $coins = isset($user->coins) ? $user->coins : 0;

        return view('credits', [
            'coins' => $coins,
        ]);
    }

    public function purchase(Request $request)
    {
        $coinQuantity = $request->input('coin_quantity');
        $pricePerCoin = 0.6;
        $totalAmount = $pricePerCoin * $coinQuantity;
        $userId = auth()->id();
        $sessionId = uniqid(); 

        try {
            Stripe::setApiKey(env('STRIPE_SECRET'));

            $checkoutSession = CheckoutSession::create([
                'payment_method_types' => ['card'],
                'line_items' => [
                    [
                        'price_data' => [
                            'currency' => 'usd',
                            'product_data' => [
                                'name' => $coinQuantity . ' Coins',
                            ],
                            'unit_amount' => $totalAmount * 100,
                        ],
                        'quantity' => 1,
                    ]
                ],
                'mode' => 'payment',
                'success_url' => route('stripe.success') . '?session_id={CHECKOUT_SESSION_ID}&unique_id=' . $sessionId,
                'cancel_url' => route('stripe.cancel'),
                'metadata' => [
                    'coin_quantity' => $coinQuantity,
                    'unique_id' => $sessionId,
                ],
            ]);

            DB::table('purchases')->insert([
                'user_id' => $userId,
                'coin_quantity' => $coinQuantity,
                'stripe_session_id' => $checkoutSession->id,
                'is_completed' => false,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return redirect($checkoutSession->url);
        } catch (\Exception $e) {
            Log::error('Stripe Checkout Session creation failed', ['error' => $e->getMessage()]);
            return redirect()->back()->withErrors('Payment creation failed.');
        }
    }


    public function success(Request $request)
    {
        $sessionId = $request->query('session_id');
        $uniqueId = $request->query('unique_id');

        if (!$sessionId || !$uniqueId) {
            return redirect()->route('stripe.cancel')
                ->withErrors(config('notifications.purchase.error.text'));
        }

        try {
            Stripe::setApiKey(env('STRIPE_SECRET'));

            $session = CheckoutSession::retrieve($sessionId);
            $coinQuantity = $session->metadata->coin_quantity;
            $sessionUniqueId = $session->metadata->unique_id;

            if ($sessionUniqueId !== $uniqueId) {
                return redirect()->route('stripe.cancel')
                    ->withErrors(config('notifications.purchase.error.text'));
            }

            $purchase = DB::table('purchases')->where('stripe_session_id', $sessionId)->first();

            if (!$purchase || $purchase->is_completed) {
                return redirect()->route('stripe.cancel')
                    ->withErrors(config('notifications.purchase.cancel.text'));
            }

            $userId = auth()->id();
            $user = DB::table('users')->where('id', $userId)->first();
            $currentCoins = isset($user->credits) ? $user->credits : 0;
            $newCoins = $currentCoins + $coinQuantity;

            DB::table('users')->where('id', $userId)->update(['credits' => $newCoins]);

            DB::table('purchases')->where('stripe_session_id', $sessionId)->update(['is_completed' => true]);

            session()->flash('notification', [
                'type' => 'success',
                'icon' => 'success',
                'title' => 'Purchase Completed',
                'text' => 'Your purchase was successful! Your new coin balance is ' . $newCoins,
            ]);

            return view('credits', [
                'coins' => $newCoins,
            ]);
        } catch (\Exception $e) {
            Log::error('Stripe payment success handling failed', ['error' => $e->getMessage()]);
            return redirect()->route('stripe.cancel')
                ->withErrors(config('notifications.purchase.error.text'));
        }
    }





    public function cancel(Request $request)
    {
        $userId = auth()->id();
        $user = DB::table('users')->where('id', $userId)->first();
        $coins = isset($user->crddits) ? $user->credits : 0;
    
        session()->flash('notification', [
            'type' => 'error',  
            'icon' => 'error',
            'title' => 'Purchase Cancelled',
            'text' => 'The purchase was cancelled or already completed.',
        ]);
    
        return view('credits', [
            'coins' => $coins,
        ]);
    }
    
}
