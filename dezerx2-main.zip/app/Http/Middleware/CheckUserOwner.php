<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;

class CheckUserOwner
{
    private $pterodactylApiBase;
    private $pterodactylApiKey;

    public function __construct()
    {
        $this->pterodactylApiBase = env('PTERODACTYL_API_URL') . '/api/application';
        $this->pterodactylApiKey = env('PTERODACTYL_API_KEY');
    }

    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();
        if (!$user) {
            return response('Unauthorized.', 401);
        }

        // Fetch servers from Pterodactyl API
        $url = "{$this->pterodactylApiBase}/servers";

        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->pterodactylApiKey,
            'Accept' => 'application/json',
        ])->withoutVerifying()->get($url);

        if (!$response->successful()) {
            return response('Service unavailable.', 503);
        }

        $servers = $response->json()['data'] ?? [];
        $requestedServerIdentifier = $request->route('identifier') ?? $request->query('identifier');

        if (is_null($requestedServerIdentifier)) {
            return response('Bad Request. Server identifier is required.', 400);
        }

        // Check server authorization
        $isAuthorized = false;
        foreach ($servers as $server) {
            $serverIdentifier = $server['attributes']['identifier'] ?? null;
            $serverOwnerId = $server['attributes']['user'] ?? null;

            if ($serverIdentifier === $requestedServerIdentifier && $serverOwnerId == $user->pterodactyl_user_id) {
                $isAuthorized = true;
                break;
            }
        }

        if (!$isAuthorized) {
            return response('Forbidden.', 403);
        }

        return $next($request);
    }
}
