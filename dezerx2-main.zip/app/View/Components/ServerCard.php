<?php

namespace App\View\Components;

use Illuminate\View\Component;

class ServerCard extends Component
{
    public $server;

    public function __construct($server)
    {
        $this->server = $server;
    }

    public function render()
    {
        return view('components.server-card');
    }
}
