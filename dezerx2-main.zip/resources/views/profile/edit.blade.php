@extends('layouts.dash')

@section('title', 'Edit Profile')

@section('content')
    <aside id="logo-sidebar"
        class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
        aria-label="Sidebar">
        <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
            <ul id="sidebar-links" class="space-y-2 font-medium">
            </ul>
        </div>
    </aside>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            @if (session('notification'))
                Swal.fire({
                    icon: "{{ session('notification.icon') }}",
                    title: "{{ session('notification.title') }}",
                    text: "{{ session('notification.text') }}",
                    showConfirmButton: true,
                    confirmButtonText: 'OK'
                });
            @endif
        });
    </script>

    <style>
        .bg-cards {
            background-color: #0c0c0c;
            border: 1px solid #1d1d1d72;
        }

        .profile-header {
            background-color: #0c0c0c;
            padding: 20px;
            text-align: center;
            border: 1px solid #1d1d1d72;
        }

        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            border: 3px solid #4a4a4a;
            object-fit: cover;
            margin: 0 auto;
        }

        .profile-username {
            color: #fff;
            font-size: 1.5rem;
            font-weight: bold;
            margin-top: 10px;
        }

        .profile-tagline {
            color: #a1a1aa;
            font-size: 1rem;
        }

        .bg-url {
            background-color: #171717;
        }

        .border-custom {
            border-bottom: 1px solid #171717;
            margin: 10px 0;
        }
    </style>

    <div class="mx-auto space-y-6">
        <!-- Profile Header with Avatar -->
        <div class="profile-header rounded-lg">
            <img src="{{ $user->avatar ?? 'https://cdn.discordapp.com/embed/avatars/0.png' }}" alt="User Avatar"
                class="profile-avatar">
            <div class="profile-username">{{ $user->name }}</div>
            <div class="profile-tagline">Edit your profile settings</div>
        </div>

<!-- Update Profile Information -->
<div class="shadow rounded-lg">
    <div class="flex gap-4">
        <!-- Update Profile Information -->
        <div class="w-1/2 rounded-lg bg-cards">
            <div class="shadow sm:rounded-lg p-8">
                @include('profile.partials.update-profile-information-form')
            </div>
        </div>
        <div class="w-1/2 rounded-lg bg-cards">
            <div class="shadow sm:rounded-lg p-8">
                @include('profile.partials.update-password-form')
            </div>
        </div>
    </div>
</div>

        
        
    </div>

    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: '{{ route('dashboard') }}',
                active: false,
            },
            {
                title: 'Deploy Instance',
                icon: 'fa-plus',
                url: 'deploy',
            },
            {
                title: 'Market Place',
                icon: 'fa-shop',
                url: 'shop',
                hasDivider: true,
            },
            {
                title: 'Credits',
                icon: 'fa-coins',
                url: 'credits',
                active: false,

            },
            {
                title: 'Fun',
                icon: 'fa-gun',
                url: 'russian-roulette',
                active: false,

            },
            {
                title: 'Website',
                icon: 'fa-globe',
                url: '{{ $ad->website ?? 'https://dezerx.com' }}',
            },
            {
                title: 'Settings',
                icon: 'fa-gears',
                url: '#',
            },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
                <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                    <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                    <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
                </a>
            `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            @if (session('notification'))
                Swal.fire({
                    icon: "{{ session('notification.icon') }}",
                    title: "{{ session('notification.title') }}",
                    text: "{{ session('notification.text') }}",
                    showConfirmButton: true,
                    confirmButtonText: 'OK'
                });
            @endif
        });
    </script>
@endsection
