@extends('layouts.dash')
@php
    $ad = \App\Models\Ad::first();
@endphp
@section('title', 'Credits')
@section('content')
    <style>
        :root {
            --bg-color-cards: #0c0c0c;
            --border-color-cards: #1d1d1d72;
            --bg-color-url: #171717;
            --bg-gradient-paypal-start: rgba(0, 9, 37, 1);
            --bg-gradient-paypal-end: rgba(0, 108, 255, 1);
        }

        .bg-cards {
            background-color: var(--bg-color-cards);
            border: 1px solid var(--border-color-cards);
        }

        .bg-icon {
            background-color: var(--bg-color-cards);
        }

        .border-devider {
            border-bottom: 1px solid var(--border-color-cards);
        }

        .bg-url {
            background-color: var(--bg-color-url);
        }

        .w-custom {
            width: fit-content;
        }

        .flex-container {
            display: flex;
            gap: 16px;
        }

        .bg-paypal {
            background: rgb(0, 9, 37);
            background: -moz-linear-gradient(159deg, var(--bg-gradient-paypal-start) 0%, var(--bg-gradient-paypal-end) 100%);
            background: -webkit-linear-gradient(159deg, var(--bg-gradient-paypal-start) 0%, var(--bg-gradient-paypal-end) 100%);
            background: linear-gradient(159deg, var(--bg-gradient-paypal-start) 0%, var(--bg-gradient-paypal-end) 100%);
            filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#000925", endColorstr="#006cff", GradientType=1);
        }
    </style>


    <!--SideBar-->
    <x-sidebar />
    <!--End-->


    <!-- Payment Forms -->
    <div class="container mx-auto">
        <div class="flex flex-col lg:flex-row w-full gap-2">
            <div class="w-full lg:w-1/2">
                <form id="paypal-form" action="{{ route('coins.purchase') }}" method="POST" class="w-full">
                    @csrf
                    <div class="bg-cards p-4 w-full rounded">
                        <div class="mb-4">
                            <h1 class="text-gray-200 text-lg font-bold mb-4">Purchase Coins with PayPal</h1>
                            <div class="flex-grow ml-1 mb-4 h-px border-b border-devider"></div>
                            <label for="coin-quantity-paypal" class="block text-gray-400 text-sm font-medium mb-2">Number of
                                Coins:</label>
                            <input type="number" id="coin-quantity-paypal" name="coin_quantity" min="1"
                                max="500" value="1" required
                                class="block w-full px-3 py-2 bg-black border-global rounded-md shadow-sm text-gray-300 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent sm:text-sm">
                        </div>
                        <button type="submit" name="payment_method" value="paypal"
                            class="w-full text-white bg-paypal font-bold py-2 px-4 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <i class="fa-brands fa-paypal"></i> Pay with PayPal
                        </button>
                        <button type="button" onclick="switchToStripe()"
                            class="w-full mt-2 text-white bg-[#1f2937] font-bold py-2 px-4 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-gray-500 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 mr-2 "
                                viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                <path fill="#ffffff"
                                    d="M64 32C28.7 32 0 60.7 0 96l0 32 576 0 0-32c0-35.3-28.7-64-64-64L64 32zM576 224L0 224 0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-192zM112 352l64 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-64 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm112 16c0-8.8 7.2-16 16-16l128 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16z" />
                            </svg>
                            <span>Switch to Card</span>
                        </button>
                    </div>
                </form>

                <form id="stripe-form" action="{{ route('stripe.purchase') }}" method="POST"
                    class="hidden w-full mt-4 lg:mt-0">
                    @csrf
                    <div class="w-full bg-cards p-4 rounded">
                        <div class="mb-4">
                            <h1 class="text-gray-200 text-lg font-bold mb-4">Purchase Coins with Credit Card</h1>
                            <div class="flex-grow mb-4 h-px border-devider"></div>
                            <label for="coin-quantity-stripe" class="block text-gray-400 text-sm font-medium mb-2">Number of
                                Coins:</label>
                            <input type="number" id="coin-quantity-stripe" name="coin_quantity" min="1"
                                max="500" value="1" required
                                class="block w-full px-3 py-2 bg-black border-global rounded-md shadow-sm text-gray-300 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent sm:text-sm">
                        </div>
                        <button type="submit" name="payment_method" value="stripe"
                            class="w-full mt-2 text-white bg-[#1f2937] font-bold py-2 px-4 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-gray-500 flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 mr-2 "
                                viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.-->
                                <path fill="#ffffff"
                                    d="M64 32C28.7 32 0 60.7 0 96l0 32 576 0 0-32c0-35.3-28.7-64-64-64L64 32zM576 224L0 224 0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-192zM112 352l64 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-64 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm112 16c0-8.8 7.2-16 16-16l128 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16z" />
                            </svg>
                            <span>Pay With Card</span>
                        </button>

                        <button type="button" onclick="switchToPayPal()"
                            class="w-full text-white mt-2 bg-paypal font-bold py-2 px-4 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <i class="fa-brands fa-paypal"></i> Switch To PayPal
                        </button>
                    </div>
                </form>
            </div>

            <div class="w-full lg:w-1/2 mt-8 lg:mt-0">
                <div class="p-6 bg-cards border-global rounded-md shadow-md">
                    <h2 class="text-2xl font-bold text-white mb-4">Claim Your Coupon</h2>
                    <div class="flex-grow mb-4 h-px border-devider"></div>
                    @if (session('success'))
                        <div class="bg-green-500 text-white p-3 rounded mb-4">
                            {{ session('success') }}
                        </div>
                    @endif
                    @if (session('error'))
                        <div class="bg-red-500 text-white p-3 rounded mb-4">
                            {{ session('error') }}
                        </div>
                    @endif
                    <form action="{{ route('claim.coupon') }}" method="POST">
                        @csrf
                        <div class="mb-4">
                            <label for="coupon_name" class="block text-sm font-medium text-gray-300">Coupon Name</label>
                            <input type="text" id="coupon_name" name="coupon_name" value="{{ old('coupon_name') }}"
                                class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                                required>
                            @error('coupon_name')
                                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                            @enderror
                        </div>
                        <button type="submit" class="px-4 py-2 bg-blue-600 w-full text-white rounded-md hover:bg-blue-700">
                            Claim Coupon
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <x-footer />



    <script>
        function switchToPayPal() {
            document.getElementById('paypal-form').classList.remove('hidden');
            document.getElementById('stripe-form').classList.add('hidden');
        }

        function switchToStripe() {
            document.getElementById('stripe-form').classList.remove('hidden');
            document.getElementById('paypal-form').classList.add('hidden');
        }

        document.addEventListener('DOMContentLoaded', function() {
            switchToPayPal();
        });
    </script>
    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: '{{ route('dashboard') }}',
                active: false,
            },
            {
                title: 'Deploy Instance',
                icon: 'fa-plus',
                url: 'deploy',
            },
            {
                title: 'Market Place',
                icon: 'fa-shop',
                url: 'shop',
                hasDivider: true,
            },
            {
                title: 'Credits',
                icon: 'fa-coins',
                url: 'credits',
                active: true,

            },
            {
                title: 'Fun',
                icon: 'fa-gun',
                url: 'russian-roulette',
                active: false,

            },
            {
                title: 'Website',
                icon: 'fa-globe',
                url: '{{ $ad->website ?? 'https://dezerx.com' }}',
            },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
                <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                    <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                    <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
                </a>
            `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            @if (session('notification'))
                Swal.fire({
                    icon: "{{ session('notification.icon') }}",
                    title: "{{ session('notification.title') }}",
                    text: "{{ session('notification.text') }}",
                    showConfirmButton: true,
                    confirmButtonText: 'OK'
                });
            @endif
        });
    </script>
@endsection
