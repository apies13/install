<div class="w-full sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-4">
    <div class="p-6 bg-cards rounded-lg border-input">
        <div class="flex items-center mb-4">
            <img src="{{ $product->image }}" alt="{{ $product->title }} Image"
                class="w-12 h-12 rounded-full mr-4">
            <h2 class="text-2xl font-semibold text-white">{{ $product->title }}</h2>
        </div>
        <ul class="space-y-4 mb-6">
            <li class="flex justify-between">
                <span class="text-gray-300 font-bold"><i class="fa-solid fa-memory mr-2"></i> RAM</span>
                <span class="text-gray-300">{{ $product->ram }} MB</span>
            </li>
            <li class="flex justify-between">
                <span class="text-gray-300 font-bold"><i class="fa-solid fa-hard-drive mr-2"></i> Disk</span>
                <span class="text-gray-300">{{ $product->disk }} MB</span>
            </li>
            <li class="flex justify-between">
                <span class="text-gray-300 font-bold"><i class="fa-solid fa-microchip mr-2"></i> CPU</span>
                <span class="text-gray-300">{{ $product->cpu }}%</span>
            </li>
            <li class="flex justify-between">
                <span class="text-gray-300 font-bold"><i class="fa-solid fa-server mr-2"></i> Slots</span>
                <span class="text-gray-300">{{ $product->slots }}</span>
            </li>
            <li class="flex justify-between">
                <span class="text-gray-300 font-bold"><i class="fa-solid fa-database mr-2"></i> Databases</span>
                <span class="text-gray-300">{{ $product->databases }}</span>
            </li>
            <li class="flex justify-between">
                <span class="text-gray-300 font-bold"><i class="fa-solid fa-network-wired mr-2"></i> Ports</span>
                <span class="text-gray-300">{{ $product->ports }}</span>
            </li>
            <li class="flex justify-between">
                <span class="text-gray-300 font-bold"><i class="fa-solid fa-download mr-2"></i> Backups</span>
                <span class="text-gray-300">{{ $product->backups }}</span>
            </li>
            <li class="text-2xl text-gray-400 font-bold"><i class="fa-solid text-yellow-400 fa-coins mr-2"></i>
                {{ $product->price }} Credits</li>
        </ul>
        <form action="{{ route('purchase', $product->id) }}" method="POST"
            onsubmit="return confirmPurchase('{{ $product->price }}')">
            @csrf
            <button @if (Auth::check() && Auth::user()->credits < $product->price) disabled @endif
                class="border border-blue-400 font-bold text-blue-400 py-2 px-4 w-full rounded-lg hover:bg-blue-400 hover:text-white transition-colors
                @if (Auth::check() && Auth::user()->credits < $product->price) cursor-not-allowed opacity-50 @endif">
                Purchase Now
            </button>
        </form>
    </div>
</div>
