<div class="bg-cards rounded-xl shadow-lg overflow-hidden transition-all duration-300 hover:shadow-2xl relative bg-cover bg-center" style="background-image: url('https://wallpaperaccess.com/full/2984692.jpg');">
<div class="backdrop-blur-sm ">
    <div class=" p-6">
        <!-- IP Address (Top Right) -->
        <div class="absolute top-4 right-4">
            <div class="bg-gray-800 bg-opacity-50 text-white rounded px-3 py-1 text-sm font-mono cursor-pointer hover:bg-opacity-75 transition-all duration-300" onclick="navigator.clipboard.writeText('{{ $server['ip_and_port'] }}')">
                {{ $server['ip_and_port'] }} <i class="fa-solid fa-copy ml-1"></i>
            </div>
        </div>

        <!-- Server status indicator -->
        <div class="flex items-center mb-4">
            <div class="w-3 h-3 rounded-full mr-2
                {{ $server['state'] === 'running' ? 'bg-green-500' : ($server['state'] === 'offline' ? 'bg-red-500' : 'bg-yellow-500') }}">
            </div>
            <span class="text-white font-semibold">{{ ucfirst($server['state']) }}</span>
        </div>

        <!-- Server details -->
        <h3 class="text-xl font-bold text-white mb-4">{{ $server['attributes']['name'] }}</h3>
        <div class="space-y-2 text-gray-300">
            <p><i class="fas fa-memory mr-2"></i>RAM: <span class="font-semibold">{{ $server['attributes']['limits']['memory'] }}MB</span></p>
            <p><i class="fas fa-microchip mr-2"></i>Cores: <span class="font-semibold">{{ $server['attributes']['limits']['cpu'] / 100 }}</span></p>
            <p><i class="fas fa-hdd mr-2"></i>Disk: <span class="font-semibold">{{ $server['attributes']['limits']['disk'] / 1024 }}GB</span></p>
        </div>
    </div>

    <!-- Manage button -->
    <div class="p-4 p-6">
        <form action="{{ url('/server/' . $server['attributes']['identifier'] . '/console') }}" method="GET">
            @csrf
            <button class="w-full bg-white bg-opacity-20 rounded-lg text-white px-4 py-2 transition-all duration-300 hover:bg-opacity-30 focus:outline-none focus:ring-2 focus:ring-white focus:ring-opacity-50">
                Manage <i class="fa-solid fa-arrow-up-right-from-square ml-2"></i>
            </button>
        </form>
    </div>
</div>
</div>
