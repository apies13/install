<footer class="bottom-0 left-0 w-full text-center py-4 text-gray-400">
    <h1 class="text-sm">
        Made with <i class="fa-solid text-red-700 fa-heart"></i> by 
        <a class="underline text-blue-600" href="https://anthonys.pro">Anthony S</a>
    </h1>
</footer>
