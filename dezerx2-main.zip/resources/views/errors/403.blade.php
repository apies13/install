{{-- resources/views/errors/403.blade.php --}}

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Access Denied - 403</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-black text-white min-h-screen flex items-center justify-center">

    <div class="text-center space-y-6">
        <h1 class="text-7xl font-extrabold text-zinc-50">403</h1>
        <p class="text-2xl font-semibold text-zinc-400">Access Denied</p>
        <p class="text-lg text-zinc-500">It seems you're using a VPN or proxy. Please disable it to access the page.</p>

        <a href="{{ url('/') }}" class="mt-8 inline-block px-8 py-3 bg-zinc-950 text-zinc-50 text-lg font-medium rounded-lg hover:bg-zinc-800 transition-all focus:outline-none focus:ring-4 focus:ring-zinc-600">
            Return Home
        </a>
    </div>

    <div class="absolute bottom-6 text-zinc-600">
        <p>&copy; {{ date('Y') }} Made with ❤️ by Anthony S.</p>
    </div>

</body>
</html>
