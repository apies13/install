@extends('layouts.auth')

@section('title', 'Register')

@section('content')
<div class="w-full bg-zinc-950 border border-zinc-900 p-8 max-w-md rounded-lg shadow-lg">
    <div class="flex items-center mb-6">
        <h2 class="text-2xl font-semibold text-white">Create an Account</h2>
    </div>

    <form method="POST" action="{{ route('register') }}" id="registerForm">
        @csrf

        <!-- Name -->
        <div class="mb-4">
            <label for="name" class="block text-sm font-medium text-gray-300">
                <i class="fa-solid fa-user"></i> Name
            </label>
            <input id="name" type="text" name="name" value="{{ old('name') }}" required autofocus autocomplete="name"
                class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Anthony S" />
            @error('name')
                <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
            @enderror
        </div>

        <!-- Email Address -->
        <div class="mb-4">
            <label for="email" class="block text-sm font-medium text-gray-300">
                <i class="fa-solid fa-envelope"></i> Email
            </label>
            <input id="email" type="email" name="email" value="{{ old('email') }}" required autocomplete="username"
                class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="anthony@dezerx.com" />
            @error('email')
                <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
            @enderror
        </div>

        <!-- Password and Confirm Password side by side -->
        <div class="flex space-x-4 mb-6">
            <!-- Password -->
            <div class="w-1/2">
                <label for="password" class="block text-sm font-medium text-gray-300">
                    <i class="fa-solid fa-key"></i> Password
                </label>
                <div class="relative">
                    <input id="password" type="password" name="password" required autocomplete="new-password"
                        class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="••••••••••" />
                    <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                        <i class="fa-solid fa-eye text-gray-300"></i>
                    </button>
                </div>
                <div id="passwordStrength" class="mt-2 h-1 rounded-full"></div>
                <p id="passwordFeedback" class="mt-1 text-xs text-gray-400"></p>
                @error('password')
                    <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
                @enderror
            </div>

            <!-- Confirm Password -->
            <div class="w-1/2">
                <label for="password_confirmation" class="block text-sm font-medium text-gray-300">
                    <i class="fa-solid fa-key"></i> Confirm Password
                </label>
                <div class="relative">
                    <input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password"
                        class="mt-1 block w-full px-4 py-2 border-global rounded-md bg-black text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        placeholder="••••••••••" />
                    <button type="button" id="toggleConfirmPassword" class="absolute inset-y-0 right-0 pr-3 flex items-center text-sm leading-5">
                        <i class="fa-solid fa-eye text-gray-300"></i>
                    </button>
                </div>
                <p id="passwordMatch" class="mt-1 text-xs"></p>
                @error('password_confirmation')
                    <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
                @enderror
            </div>
        </div>

        <!-- Turnstile CAPTCHA -->
        <div class="mb-4">
            <div class="cf-turnstile" data-sitekey="{{ config('services.turnstile.site_key') }}"></div>
            @error('cf-turnstile-response')
                <p class="mt-2 text-sm text-red-400">{{ $message }}</p>
            @enderror
        </div>

        <button type="submit" id="registerButton"
            class="bg-indigo-600 w-full text-white px-4 py-2 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition duration-150 ease-in-out">
            Register
        </button>

        <p class="text-gray-400 mt-6 mb-6">
            Already registered? <a href="{{ route('login') }}" class="text-indigo-500 hover:underline">Log in</a>.
        </p>

        <div class="relative mt-6 w-full">
            <div class="absolute inset-x-0 top-1/2 transform -translate-y-1/2 text-center">
                <span class="bg-zinc-950 px-2 text-gray-300">OR</span>
            </div>
            <div class="border-b border-zinc-900 w-full"></div>
        </div>
    </form>

    <div class="mt-6">
        <a href="/auth/discord/redirect"
            class="flex bg-indigo-600 items-center justify-center px-4 py-2 text-base font-medium rounded-md text-white border border-indigo-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 w-full transition duration-150 ease-in-out hover:bg-indigo-700">
            <i class="fa-brands fa-discord mr-2"></i> Register with Discord
        </a>
    </div>
</div>

<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('password_confirmation');
    const passwordStrength = document.getElementById('passwordStrength');
    const passwordFeedback = document.getElementById('passwordFeedback');
    const passwordMatch = document.getElementById('passwordMatch');
    const registerButton = document.getElementById('registerButton');
    const togglePassword = document.getElementById('togglePassword');
    const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');

    function updatePasswordStrength() {
        const strength = calculatePasswordStrength(password.value);
        passwordStrength.style.width = `${strength}%`;
        passwordStrength.style.backgroundColor = getStrengthColor(strength);
        passwordFeedback.textContent = getStrengthText(strength);
    }

    function calculatePasswordStrength(password) {
        let strength = 0;
        if (password.length > 6) strength += 20;
        if (password.length > 10) strength += 20;
        if (/[A-Z]/.test(password)) strength += 20;
        if (/[0-9]/.test(password)) strength += 20;
        if (/[^A-Za-z0-9]/.test(password)) strength += 20;
        return strength;
    }

    function getStrengthColor(strength) {
        if (strength < 40) return '#ff4136';
        if (strength < 80) return '#ffdc00';
        return '#2ecc40';
    }

    function getStrengthText(strength) {
        if (strength < 40) return 'Weak';
        if (strength < 80) return 'Moderate';
        return 'Strong';
    }

    function checkPasswordMatch() {
        if (password.value === confirmPassword.value) {
            passwordMatch.textContent = 'Passwords match';
            passwordMatch.classList.remove('text-red-400');
            passwordMatch.classList.add('text-green-400');
            registerButton.disabled = false;
        } else {
            passwordMatch.textContent = 'Passwords do not match';
            passwordMatch.classList.remove('text-green-400');
            passwordMatch.classList.add('text-red-400');
            registerButton.disabled = true;
        }
    }

    function togglePasswordVisibility(inputField, toggleButton) {
        const type = inputField.getAttribute('type') === 'password' ? 'text' : 'password';
        inputField.setAttribute('type', type);
        toggleButton.innerHTML = type === 'password' ? '<i class="fa-solid fa-eye text-gray-300"></i>' : '<i class="fa-solid fa-eye-slash text-gray-300"></i>';
    }

    password.addEventListener('input', updatePasswordStrength);
    password.addEventListener('input', checkPasswordMatch);
    confirmPassword.addEventListener('input', checkPasswordMatch);
    togglePassword.addEventListener('click', () => togglePasswordVisibility(password, togglePassword));
    toggleConfirmPassword.addEventListener('click', () => togglePasswordVisibility(confirmPassword, toggleConfirmPassword));

    updatePasswordStrength();
    checkPasswordMatch();
});
</script>
@endsection
