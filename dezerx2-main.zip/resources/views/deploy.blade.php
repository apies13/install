@extends('layouts.dash')
@php
    $ad = \App\Models\Ad::first();
@endphp
@section('title', 'Deploy Instance')

@section('content')
    <style>
        :root {
            --bg-color-cards: #0c0c0c;
            --border-color-cards: #1d1d1d72;
            --bg-color-icon: #0c0c0c;
            --border-color-icon: #1a1a1a;
            --shadow-black: 0px 0px 6px #000;
            --border-color-global: #1d1d1d;
            --bg-color-url: #171717;
            --shadow-blue: 0px 0px 5px #000;
        }

        .bg-cards {
            background-color: var(--bg-color-cards);
            border: 1px solid var(--border-color-cards);
        }

        .bg-icon {
            background-color: var(--bg-color-icon);
            border: 1px solid var(--border-color-icon);
        }

        .black-shadow {
            box-shadow: var(--shadow-black);
        }

        .border-devider {
            border-color: var(--border-color-global);
        }

        .border-global {
            border: 1px solid var(--border-color-global);
        }

        .bg-url {
            background-color: var(--bg-color-url);
        }

        .w-custom {
            width: fit-content;
        }

        .header {
            position: relative;
            background-size: cover;
            background-position: center;
            height: 200px;
            color: white;
        }

        .header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 1));
            z-index: 1;
        }

        .header>* {
            position: relative;
            z-index: 2;
        }

        .blue-shadow {
            box-shadow: var(--shadow-blue);
        }
    </style>

    <x-sidebar />


    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <x-resource-card icon="fa-solid fa-memory" title="Default RAM" value="{{ Auth::user()->ram }}" unit="MB" />
        <x-resource-card icon="fa-solid fa-microchip" title="Default CPU" value="{{ Auth::user()->cpu }}" unit="%" />
        <x-resource-card icon="fa-solid fa-hdd" title="Default Disk" value="{{ Auth::user()->disk / 1024 }}"
            unit="GB" />
        <x-resource-card icon="fa-solid fa-users" title="Default Slots" value="{{ Auth::user()->slots }}" />
    </div>


    <x-server-form :locations="$locations" />

    <x-footer />


    </main>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const eggSelect = document.getElementById('egg');

            eggSelect.addEventListener('change', function() {
                const selectedOption = eggSelect.options[eggSelect.selectedIndex];
                const nestId = selectedOption.getAttribute('data-nest-id');
                console.log('Selected Nest ID:', nestId);
                const nestIdInput = document.getElementById('nest-id');
                nestIdInput.value = nestId;

            });
        });
    </script>
    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: '{{ route('dashboard') }}',
                active: false,
            },
            {
                title: 'Deploy Instance',
                icon: 'fa-plus',
                url: 'deploy',
                active: true,
            },
            {
                title: 'Market Place',
                icon: 'fa-shop',
                url: 'shop',
                hasDivider: true,
                active: false,

            },
            {
                title: 'Credits',
                icon: 'fa-coins',
                url: 'credits',
                active: false,

            },
            {
                title: 'Fun',
                icon: 'fa-gun',
                url: 'russian-roulette',
                active: false,

            },
            {
                title: 'Website',
                icon: 'fa-globe',
                url: '{{ $ad->website ?? 'https://dezerx.com' }}',
            },

        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
                <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                    <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                    <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
                </a>
            `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            @if (session('notification'))
                Swal.fire({
                    icon: "{{ session('notification.icon') }}",
                    title: "{{ session('notification.title') }}",
                    text: "{{ session('notification.text') }}",
                    showConfirmButton: true,
                    confirmButtonText: 'OK'
                });
            @endif
        });
    </script>
@endsection
