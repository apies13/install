@extends('layouts.dash')
@php
    $ad = \App\Models\Ad::first();
@endphp
@section('title', 'Dashboard')
@section('content')
    <style>
        :root {
            --bg-color-cards: #0c0c0c;
            --border-color-cards: #1d1d1d72;
            --bg-color-icon: #0c0c0c;
            --border-color-icon: #1a1a1a;
            --shadow-black: 0px 0px 6px #000;
            --border-color-global: #1d1d1d;
            --bg-color-url: #171717;
            --shadow-blue: 0px 0px 5px #000;
        }

        .bg-cards {
            background-color: var(--bg-color-cards);
            border: 1px solid var(--border-color-cards);
        }

        .bg-icon {
            background-color: var(--bg-color-icon);
            border: 1px solid var(--border-color-icon);
        }

        .black-shadow {
            box-shadow: var(--shadow-black);
        }

        .border-devider {
            border-color: var(--border-color-global);
        }

        .border-global {
            border: 1px solid var(--border-color-global);
        }

        .bg-url {
            background-color: var(--bg-color-url);
        }

        .w-custom {
            width: fit-content;
        }


        .header {
            position: relative;
            background-size: cover;
            background-position: center;
            height: 300px;
            background-image: url("https://wallpaperaccess.com/full/2984692.jpg");

            color: white;
        }

        .header::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 1));
            z-index: 1;
        }

        .header>* {
            position: relative;
            z-index: 2;
        }

        .blue-shadow {
            box-shadow: var(--shadow-blue);
        }
    </style>


    <!--SideBar--->
    <x-sidebar />
    <!--End--->


    <!-------------------------------------------->


    <!--Header Notification--->
    <div id="service-card" class="bg-cards shadow-lg p-4 mb-3 rounded-lg flex items-center justify-between">
        <div>
            <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-300">
                Welcome to
                <a class="underline" href="https://dezerx.com">DezerX</a> Dashboard. Servers are billed at
                <span class="text-blue-700">{{ $renewal_cost }}$</span>/min
            </h2>
        </div>
    </div>
        <!--End--->


    <!-------------------------------------------->


    <!--Resource Cards--->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <x-resource-card icon="fa-solid fa-memory" title="Default RAM" value="{{ Auth::user()->ram }}" unit="MB" />
        <x-resource-card icon="fa-solid fa-microchip" title="Default CPU" value="{{ Auth::user()->cpu }}" unit="%" />
        <x-resource-card icon="fa-solid fa-hdd" title="Default Disk" value="{{ Auth::user()->disk / 1024 }}"
            unit="MB" />
        <x-resource-card icon="fa-solid fa-server" title="Default Slots" value="{{ Auth::user()->slots }}" />
    </div>
    <div class="title flex items-center space-x-4">
        <h1 class="mt-6 font-semibold text-gray-300 text-lg"><i class="fa-solid fa-server"></i> Your Instances</h1>
        <div class="border-t mt-6 border-devider flex-1"></div>
    </div>
    <!--End--->


    <!-------------------------------------------->


<!--Server cards--->
@if (empty($servers))
    <div class="flex flex-col items-center mt-24">
        <img src="https://th.bing.com/th/id/R.fa17adb5836c99285173b9b48ca1b47f?rik=%2fDQFxn15Ze8ANQ&riu=http%3a%2f%2fpluspng.com%2fimg-png%2fwind-blowing-png-hd-clip-1129.png&ehk=YLqo4kl4t1HBxe0c7RZutyYX60ptl%2fQwY8y2bs%2bqz5g%3d&risl=&pid=ImgRaw&r=0"
            alt="No servers available" class="w-48 h-32 mb-4">
        <h1 class="text-gray-400 text-lg">
            You don't have any servers yet.
        </h1>
        <a href="/deploy" class="text-blue-500 underline cursor-pointer">Create one!</a>
    </div>
@else
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        @foreach ($servers as $server)
            <x-server-card :server="$server" />
        @endforeach
    </div>
@endif
<!--End--->

    <!-------------------------------------------->


    <!--Footer--->
    <x-footer />
    <!--End--->


    <!-------------------------------------------->


    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: 'dashboard',
                active: true,
            },
            {
                title: 'Deploy Instance',
                icon: 'fa-plus',
                url: 'deploy',
            },
            {
                title: 'Market Place',
                icon: 'fa-shop',
                url: 'shop',
                hasDivider: true,
            },
            {
                title: 'Credits',
                icon: 'fa-coins',
                url: 'credits',
            },
            {
                title: 'Fun',
                icon: 'fa-gun',
                url: 'russian-roulette',
                active: false,

            },
            {
                title: 'Website',
                icon: 'fa-globe',
                url: '{{ $ad->website ?? 'https://dezerx.com' }}',
            },

        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            @if (session('notification'))
                Swal.fire({
                    icon: "{{ session('notification.icon') }}",
                    title: "{{ session('notification.title') }}",
                    text: "{{ session('notification.text') }}",
                    showConfirmButton: true,
                    confirmButtonText: 'OK'
                });
            @endif
        });
    </script>

@endsection
