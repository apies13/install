<style>
    body {
        font-family: "Quicksand", sans-serif;
    }
    .bg-sidebar {
        background-color: #0f0f11;
    }
    .border-custom {
        border-bottom: 1px solid #1d1d1d;
    }
    .border-navbar {
        border-bottom: 1px solid #1d1d1d;
    }
    .border-sidebar {
        border-right: 1px solid #1d1d1d;
    }
    @media (prefers-color-scheme: dark) {
    .dark\:bg-gray-900\/80 {
        background-color: black !important;
    }
}
    .bg-icons {
        background-color: #171719;
        border-radius: 10px;
        padding-top: 10px;
        padding-bottom: 10px;
        padding-left: 10px;
        padding-right: 10px;
        border: 1px solid #1d1d1d;


    }
    .bg-icon {
        background-color: #171719;
    }
    .border-global {
        border: 1px solid #1d1d1d;
    }
    .devide-gray-900 {
        border-color: #1d1d1d !important;
    }
    </style>
<nav class="bg-black fixed top-0 z-50 w-full bg-sidebar border-navbar dark:bg-sidebar dark:border-gray-700">
    <div class="px-3 py-3 lg:px-5 lg:pl-3">
      <div class="flex items-center justify-between">
        <div class="flex items-center justify-start rtl:justify-end">
          <button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 text-sm text-gray-500 rounded-lg sm:hidden focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:focus:ring-gray-600">
              <span class="sr-only">Open sidebar</span>
              <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                 <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
              </svg>
           </button>
          <a href="#" class="flex ms-2 md:me-24">
            <img src="https://images.vexels.com/media/users/3/155806/isolated/preview/b29d14472d5272374a754e05554f03ae-hexagon-icon-by-vexels.png" class="h-8 me-3" alt="Logo" />
            <span class="self-center text-xl font-semibold sm:text-2xl whitespace-nowrap dark:text-white">DezerX</span>
          </a>
        </div>
        <div class="flex items-center">
            <div class="flex items-center ms-3">
              <div>
                <button type="button" class=" flex text-sm bg-sidebar rounded-full focus:ring-4 focus:ring-gray-300 dark:focus:ring-gray-600" aria-expanded="false" data-dropdown-toggle="dropdown-user">
                  <span class="sr-only">Open user menu</span>
                  <img class="w-8 h-8 rounded-full" src="https://cdn.pfps.gg/pfps/2006-orange-cat.png" alt="user photo">
                </button>
              </div>
              <div class="z-50 hidden  text-base list-none rounded shadow border-global bg-sidebar" id="dropdown-user">
                <div class="px-4 py-3" role="none">
                  <p class="text-sm text-gray-900 dark:text-white" role="none">
                    Anthony S
                  </p>
                  <p class="text-sm font-medium text-gray-900 truncate dark:text-gray-300" role="none">
                    anthony@dezerx.com
                  </p>
                </div>
                <div class="border-custom w-full"></div>

                <ul class="py-1" role="none">
                  
                 
                    <form id="logout-form" method="POST" action="{{ route('logout') }}" class="hidden">
                        @csrf
                    </form>
                    
                    <a href="#" class="block px-4 py-2 text-sm text-gray-300" role="menuitem" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        Log out
                    </a>
                    
                  <li>
                    <a href="#" class="block px-4 py-2 text-sm text-gray-300 " role="menuitem">Profile Settings</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
      </div>
    </div>
  </nav>
  
  <aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full  bg-sidebar border-sidebar sm:translate-x-0 dark:border-gray-700" aria-label="Sidebar">
     <div class="h-full px-3 pb-4 overflow-y-auto  bg-sidebar">
        <ul class="space-y-2 font-medium">
           <li>
              <a href="#" class="flex items-center bg-icons p-2 text-gray-900 rounded-lg dark:text-white  group">
                <i class="fa-solid fa-lg text-gray-300 fa-desktop"></i>
                 <span class="ms-3">Overview</span>
              </a>
           </li>
           <li>
              <a href="#" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white  group">
                <i class="fa-solid text-gray-300 fa-plus fa-lg"></i>
                   <span class="flex-1 ms-3 whitespace-nowrap">Deploy Instance</span>
              </a>
           </li>
           <li>
              <a href="#" class="flex items-center hover:bg-icon p-2 text-gray-900 rounded-lg dark:text-white  group">
                <i class="fa-solid fa-lg text-gray-300 fa-shop"></i>

                 <span class="flex-1 ms-3 whitespace-nowrap">Market Place</span>
              </a>
           </li>
           <li>
              <a href="#" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white  group">
                <i class="fa-solid fa-lg text-gray-300 fa-coins"></i>

                 <span class="flex-1 ms-3 whitespace-nowrap">Credits</span>
              </a>
           </li>
           <div class="border-custom w-full"></div>
           <li>
              <a href="#" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white  group">
                <i class="fa-solid text-gray-300 fa-lg fa-gear"></i>
                 <span class="flex-1 ms-3 whitespace-nowrap">Settings</span>
              </a>
           </li>
           <li>
              <a href="#" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white  group">
                <i class="fa-solid text-gray-300 fa-lg fa-headphones-simple"></i>

                 <span class="flex-1 ms-3 whitespace-nowrap">Support</span>
              </a>
           </li>
         
        </ul>
     </div>
  </aside>