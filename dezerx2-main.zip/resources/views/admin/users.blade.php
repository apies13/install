@extends('admin.layouts.app')

@section('title', 'View Users')

@section('content')
    <style>
        .bg-cards {
            background-color: #0f0f11;
            border: 1px solid #1d1d1d;
        }

        .bg-cards-1 {
            background-color: #070707;
            border: 1px solid #1d1d1d;
        }

        .bg-icon {
            background-color: #0f0f11;
            box-shadow: 0px 0px 4px #000;
            border: 1px solid #1d1d1d;
        }

        .border-devider {
            border-color: #1d1d1d;

        }

        .border-bottom-1 {
            border-bottom: 1px solid #1d1d1d;
        }

        .border-global {
            border: 1px solid #1d1d1d;
        }

        .bg-url {
            background-color: #171719;
            border: 1px solid #1d1d1d;
        }

        .w-custom {
            width: fit-content;
        }
    </style>

    <aside id="logo-sidebar"
        class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
        aria-label="Sidebar">
        <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
            <ul id="sidebar-links" class="space-y-2 font-medium">

            </ul>
        </div>
    </aside>



<table class="min-w-full bg-cards shadow-lg" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">

    <thead class="">
        <div class="bg-cards-1 p-2 w-full"
            style="border-top: 2px solid #2536EB; border-bottom: 1px solid rgb(31 41 55 / 30%)">
            <h1 class="font-semibold text-xl text-white"> Users List </h1>
        </div>
        <tr>
            <th class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">ID
            </th>
            <th class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">Email
            </th>
            <th class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                Username</th>
            <th class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                Credits</th>
            <th class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                Role</th>
            <th class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($users as $user)
            <tr>
                <td class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                    {{ $user['id'] }}</td>
                <td class="py-2 px-4  text-blue-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                    {{ $user['email'] }}
                </td>
                <td class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                    {{ $user['name'] }}</td>
                    <td class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                        <form action="{{ route('admin.user.updateCredits', $user['id']) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <input type="text" name="credits" value="{{ $user['credits'] }}" class="editable-credits p-2 rounded-xl bg-zinc-950" 
                                onkeypress="if(event.key === 'Enter'){ this.form.submit(); }" />
                            <button type="submit" class="text-green-500 ml-2 hover:text-green-700">Edit</button>
                        </form>
                    </td>
                <td class="py-2 px-4 text-center text-gray-300" style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                    @if ($user['role'] == 'Admin')
                        <i class="fa-solid fa-crown text-orange-500"></i>
                    @else
                        {{ $user['role'] }}
                    @endif
                </td>
                <td class="py-2 px-4 text-gray-300 border-b " style="border-bottom: 1px solid rgb(31 41 55 / 30%);">
                    @if ($user['role'] == 'Admin')
                        <button type="button" class="text-gray-500 cursor-not-allowed" title="Actions Disabled">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    @else
                        <form action="{{ route('admin.user.delete', $user['id']) }}" method="POST" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 hover:text-red-800" title="Delete Server">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </form>
                    @endif
                </td>
            </tr>
        @endforeach
    </tbody>
</table>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.editable-credits').forEach(function (input) {
        input.addEventListener('blur', function () {
            let newCredits = this.value;
            let userId = this.getAttribute('data-id');

            fetch(`/admin/users/${userId}/update-credits`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: JSON.stringify({ credits: newCredits })
            }).then(response => {
                if (!response.ok) {
                    alert('Failed to update credits');
                }
            }).catch(error => {
                console.error('Error:', error);
            });
        });
    });
});
</script>



    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: 'dashboard',
            },
            {
                title: 'Users',
                icon: 'fa-users',
                url: 'users',
                active: true,
            },
            {
                title: 'Products',
                icon: 'fa-box',
                url: 'products',
            },
            {
                title: 'Settings',
                icon: 'fa-gear',
                url: 'settings',
                hasDivider: true,
            },
            {
                title: 'Servers',
                icon: 'fa-server',
                url: 'servers',
            },
            {
            title: 'Images',
            icon: 'fa-egg',
            url: '{{ route('admin.eggs') }}',
        },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
@endsection
