@extends('admin.layouts.app')

@section('title', 'Settings')

@section('content')
    <style>
        .bg-cards {
            background-color: #0f0f11;
            border: 1px solid #1d1d1d;
        }

        .bg-cards-1 {
            background-color: #070707;
            border: 1px solid #1d1d1d;
        }

        .bg-icon {
            background-color: #0f0f11;
            box-shadow: 0px 0px 4px #000;
            border: 1px solid #1d1d1d;
        }

        .border-devider {
            border-color: #1d1d1d;

        }

        .border-bottom-1 {
            border-bottom: 1px solid #1d1d1d;
        }

        .border-global {
            border: 1px solid #1d1d1d;
        }

        .bg-url {
            background-color: #171719;
            border: 1px solid #1d1d1d;
        }

        .w-custom {
            width: fit-content;
        }
    </style>

    <aside id="logo-sidebar"
        class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
        aria-label="Sidebar">
        <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
            <ul id="sidebar-links" class="space-y-2 font-medium">

            </ul>
        </div>
    </aside>


    <div class="flex flex-col justify-center">
        <div class="flex flex-col lg:flex-row lg:space-y-0 lg:space-x-4">
            <!-- Purger Card -->

        
            <!-- Form Card -->
            <div class="bg-cards shadow-lg w-full p-6 rounded-lg">
                <form action="{{ route('store.ads') }}" method="POST">
                    @csrf
                    <!-- Name Input -->
                    <div class="mb-4">
                        <label for="name" class="block text-sm font-medium text-gray-300">Name</label>
                        <input type="text" value="DezerX" id="name" name="name" value="{{ old('name') }}"
                            class="mt-1 block w-full p-3 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                            required>
                        @error('name')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
        
                    <!-- Description Input -->
                    <div class="mb-4">
                        <label for="description" class="block text-sm font-medium text-gray-300">Description</label>
                        <input type="text" id="description" name="description" value="{{ old('description') }}"
                            class="mt-1 block w-full p-3 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                            required>
                        @error('description')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
        
                    <!-- Website Input -->
                    <div class="mb-4">
                        <label for="website" class="block text-sm font-medium text-gray-300">Website</label>
                        <input type="text" value="https://dezerx.com" id="website" name="website" value="{{ old('website') }}"
                            class="mt-1 block w-full p-3 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                            required>
                        @error('website')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
        
                    <!-- Logo URL Input -->
                    <div class="mb-4">
                        <label for="logo_url" class="block text-sm font-medium text-gray-300">Logo URL</label>
                        <input type="text" id="logo_url" name="logo_url" value="{{ old('logo_url') }}"
                            class="mt-1 block w-full p-3 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                            required>
                        @error('logo_url')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                        @enderror
                    </div>
        
                    <!-- Save Changes Button -->
                    <button type="submit" class="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
                        Save Changes
                    </button>
                </form>
            </div>
        </div>
        
    
        <!-- Form Card -->
       
    </div>
    <div class="p-6 mt-4 bg-cards border-global rounded-lg shadow-md">
        <h2 class="text-2xl font-bold text-white mb-4">Add New Coupon</h2>

        @if (session('success'))
            <div class="bg-green-500 text-white p-3 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        <form action="{{ route('store.coupons') }}" method="POST">
            @csrf
        
            <div class="grid grid-cols-2 gap-4">
                <!-- Row 1: Name and Uses -->
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-300">Name</label>
                    <input type="text" id="name" name="name" value="{{ old('name') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                        required>
                    @error('name')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <div class="mb-4">
                    <label for="uses" class="block text-sm font-medium text-gray-300">Uses</label>
                    <input type="number" id="uses" name="uses" value="{{ old('uses') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                        required>
                    @error('uses')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <!-- Row 2: RAM and Credits -->
                <div class="mb-4">
                    <label for="ram" class="block text-sm font-medium text-gray-300">RAM (MB)</label>
                    <input type="number" id="ram" name="ram" value="{{ old('ram') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('ram')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <div class="mb-4">
                    <label for="credits" class="block text-sm font-medium text-gray-300">Credits</label>
                    <input type="number" id="credits" name="credits" value="{{ old('credits') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('credits')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <!-- Row 3: CPU and Disk -->
                <div class="mb-4">
                    <label for="cpu" class="block text-sm font-medium text-gray-300">CPU Cores</label>
                    <input type="number" id="cpu" name="cpu" value="{{ old('cpu') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('cpu')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <div class="mb-4">
                    <label for="disk" class="block text-sm font-medium text-gray-300">Disk Space (GB)</label>
                    <input type="number" id="disk" name="disk" value="{{ old('disk') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('disk')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <!-- Row 4: Slots and Databases -->
                <div class="mb-4">
                    <label for="slots" class="block text-sm font-medium text-gray-300">Slots</label>
                    <input type="number" id="slots" name="slots" value="{{ old('slots') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('slots')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <div class="mb-4">
                    <label for="databases" class="block text-sm font-medium text-gray-300">Databases</label>
                    <input type="number" id="databases" name="databases" value="{{ old('databases') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('databases')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <!-- Row 5: Ports and Backups -->
                <div class="mb-4">
                    <label for="ports" class="block text-sm font-medium text-gray-300">Ports</label>
                    <input type="number" id="ports" name="ports" value="{{ old('ports') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('ports')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
        
                <div class="mb-4">
                    <label for="backups" class="block text-sm font-medium text-gray-300">Backups</label>
                    <input type="number" id="backups" name="backups" value="{{ old('backups') }}"
                        class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">
                    @error('backups')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                Add Coupon
            </button>
        </form>
        
    </div>
    
    


















    


    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: 'dashboard',
            },
            {
                title: 'Users',
                icon: 'fa-users',
                url: 'users',
            },
            {
                title: 'Products',
                icon: 'fa-box',
                url: 'products',
            },
            {
                title: 'Settings',
                icon: 'fa-gear',
                url: 'settings',
                hasDivider: true,
                active: true,
            },
            {
                title: 'Servers',
                icon: 'fa-server',
                url: 'servers',
            },
            {
            title: 'Images',
            icon: 'fa-egg',
            url: '{{ route('admin.eggs') }}',
        },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
@endsection
