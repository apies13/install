@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
    <style>
        .bg-cards {
            background-color: #0f0f11;
            border: 1px solid #1d1d1d;
        }

        .bg-icon {
            background-color: #0f0f11;
            box-shadow: 0px 0px 4px #000;
            border: 1px solid #1d1d1d;
        }

        .border-devider {
            border-color: #1d1d1d;

        }

        .border-global {
            border: 1px solid #1d1d1d;
        }

        .bg-url {
            background-color: #171719;
            border: 1px solid #1d1d1d;
        }

        .w-custom {
            width: fit-content;
        }
    </style>

<aside id="logo-sidebar"
class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full border-sidebar sm:translate-x-0"
aria-label="Sidebar">
<div class="h-full px-3 pb-4 overflow-y-auto ">
    <ul id="sidebar-links" class="space-y-2 font-medium">

    </ul>
</div>
</aside>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Card 1 -->
        <div class="bg-cards border border-zinc-900 rounded-lg shadow-lg p-4 flex items-center">
            <div class="bg-icon py-2 px-3 rounded mr-3">
                <i class="fa-solid fa-memory text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Default RAM</h2>
                <p class=" text-gray-600 dark:text-gray-400">{{ $ram }}MB</p>
            </div>
        </div>

        <!-- Card 2 -->
        <div class="bg-cards border border-zinc-900 rounded-lg shadow-lg p-4 flex items-center">
            <div class="bg-icon py-2 px-3 rounded mr-3">
                <i class="fa-solid fa-microchip text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Default CPU</h2>
                <p class=" text-gray-600 dark:text-gray-400">{{ $cpu }}%</p>
            </div>
        </div>

        <!-- Card 3 -->
        <div class="bg-cards border border-zinc-900 rounded-lg shadow-lg p-4 flex items-center">
            <div class="bg-icon py-2 px-3 rounded mr-3">
                <i class="fa-solid fa-hdd text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Default Disk</h2>
                <p class=" text-gray-600 dark:text-gray-400">{{ $disk }}MB</p>
            </div>
        </div>

        <!-- Card 4 -->
        <div class="bg-cards border border-zinc-900 rounded-lg shadow-lg p-4 flex items-center">
            <div class="bg-icon py-2 px-3 rounded mr-3">
                <i class="fa-solid fa-network-wired text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Default Ports</h2>
                <p class=" text-gray-600 dark:text-gray-400">{{ $ports }}</p>
            </div>
        </div>

        <!-- Card 5 -->
        <div class="bg-cards border border-zinc-900 rounded-lg shadow-lg p-4 flex items-center">
            <div class="bg-icon py-2 px-3 rounded mr-3">
                <i class="fa-solid fa-database text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Default Databases</h2>
                <p class=" text-gray-600 dark:text-gray-400">{{ $databases }}</p>
            </div>
        </div>

        <!-- Card 6 -->
        <div class="bg-cards border border-zinc-900  rounded-lg shadow-lg p-4 flex items-center">
            <div class="bg-icon py-2 px-3 rounded mr-3">
                <i class="fa-solid fa-copy text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Default Backups</h2>
                <p class=" text-gray-600 dark:text-gray-400">{{ $backups }}</p>
            </div>
        </div>

        <!-- Card 7 -->
        <div class="bg-cards border border-zinc-900 rounded-lg shadow-lg p-4 flex items-center">
            <div class="bg-icon py-2 px-3 rounded mr-3">
                <i class="fa-solid fa-users text-white"></i>
            </div>
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Default Slots</h2>
                <p class=" text-gray-600 dark:text-gray-400">{{ $slots }}</p>
            </div>
        </div>

        
    </div>

    <style>
        .height-custom {
            height: auto;
        }
    </style>
    </div>
    <div class="mt-4 flex w-full space-x-4">
        <div class="bg-cards border border-zinc-900 shadow-lg rounded-lg p-4 flex flex-col justify-between h-full">
            <div>
                <h2 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Update Default Resources</h2>
                <p class="text-gray-600 mb-4 dark:text-gray-400">Upon user registration, each user gets allocated default
                    resources</p>
            </div>
            <div class="mt-auto w-full">
                <a id="edit-resources-btn" class="bg-blue-800 rounded-lg text-white w-full px-4 py-2 block text-center" href="#">
                    Edit Resources <i class="fa-solid fa-pen-to-square"></i>
                </a>
            </div>
        </div>
        
        <div class="bg-cards border border-zinc-900 rounded-lg shadow-lg p-4 flex-1">
            <div>
                <h2 class="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">Purger</h2>
                <p class="text-gray-600 dark:text-gray-400 mb-2">
                    Wanna purge servers without a specific keyword?
                </p>
                <button data-modal-target="authentication-modal" data-modal-toggle="authentication-modal"
                    class="inline-flex items-center justify-center w-full bg-red-700 hover:bg-red-800 text-white font-medium rounded-lg text-sm px-5 py-2.5 focus:ring-4 focus:ring-red-300">
                    Purge <i class="fa-solid fa-trash ml-2"></i>
                </button>
            </div>
        </div>
    </div>
    

    <form class="rounded-lg bg-cards border border-zinc-900 mt-4 p-4" action="{{ route('store.location') }}" method="POST">
        @csrf

        <div class="mb-4">
            <label for="location_id" class="block text-sm font-medium text-gray-300">Location ID ( make sure it's the actual ID of a location )</label>
            <input type="number" placeholder="1" id="location_id" name="location_id" value="{{ old('location_id') }}"
                class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                required>
            @error('location_id')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="location_name" class="block text-sm font-medium text-gray-300">Location Name</label>
            <input type="text" placeholder="France" id="location_name" name="location_name" value="{{ old('location_name') }}"
                class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                required>
            @error('location_name')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="fee" class="block text-sm font-medium text-gray-300">Fee ( in $ for example 3 is 3$ )</label>
            <input type="number" id="fee" name="fee" value="{{ old('fee') }}"
                class="mt-1 block w-full p-2 bg-black border-global rounded-md text-white focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"
                required>
            @error('fee')
                <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
            @enderror
        </div>

        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            Add Location
        </button>
    </form>


    @if (isset($deletedCount))
        <div class="alert alert-success">
            {{ $deletedCount }} server(s) have been deleted.
        </div>
    @endif

    <div id="authentication-modal" tabindex="-1" aria-hidden="true"
        class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
        <div class="relative p-4 w-full max-w-md max-h-full">
            <!-- Modal content -->
            <div class="relative bg-cards rounded-lg shadow dark:bg-cards">
                <!-- Modal header -->
                <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600">
                    <h3 class="text-xl font-semibold text-gray-900 dark:text-white">
                        Purger
                    </h3>
                    <button type="button"
                        class="end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                        data-modal-hide="authentication-modal">
                        <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                            viewBox="0 0 14 14">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                        </svg>
                        <span class="sr-only">Close modal</span>
                    </button>
                </div>
                <!-- Modal body -->
                <div class="p-4 md:p-5">
                    <form class="space-y-4" action="{{ route('filter.servers') }}" method="POST">
                        @csrf
                        <div>
                            <label for="keyword" class="block mb-2 text-sm font-medium text-white">Keyword</label>
                            <input type="text" name="keyword" id="keyword"
                                class="bg-black border-global text-white text-sm rounded-lg focus:ring-red-500 focus:border-red-500 block w-full p-2.5"
                                placeholder="Active" required />
                        </div>

                        <button type="submit"
                            class="w-full text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 font-medium rounded text-sm px-5 py-2.5 text-center">Purge
                            now! <i class="fa-solid fa-trash"></i></button>
                    </form>
                </div>
            </div>   
        </div>
    </div>

    <div id="resources-form" class=" hidden mt-4 p-8 bg-stone-900/40 border border-zinc-900 rounded shadow-lg">
        <h2 class="text-3xl font-bold text-white mb-8">Update Default Resources</h2>
        <form action="{{ route('update.default.resources') }}" method="POST" class="space-y-6">
            @csrf
            <!-- Default RAM -->
            <div class="flex flex-col space-y-2">
                <label for="default_ram" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Default RAM (MB)</span>
                </label>
                <input type="number" id="default_ram" name="default_ram"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('default_ram') ?? $ram }}" required placeholder="2048">
            </div>

            <!-- Default CPU -->
            <div class="flex flex-col space-y-2">
                <label for="default_cpu" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Default CPU</span>
                </label>
                <input type="number" id="default_cpu" name="default_cpu"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('default_cpu') ?? $cpu }}" required placeholder="4">
            </div>

            <!-- Default Disk -->
            <div class="flex flex-col space-y-2">
                <label for="default_disk" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Default Disk (MB)</span>
                </label>
                <input type="number" id="default_disk" name="default_disk"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('default_disk') ?? $disk }}" required placeholder="100">
            </div>

            <!-- Default Slots -->
            <div class="flex flex-col space-y-2">
                <label for="default_slots" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Default Slots</span>
                </label>
                <input type="number" id="default_slots" name="default_slots"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('default_slots') ?? $slots }}" required placeholder="10">
            </div>

            <!-- Default Ports -->
            <div class="flex flex-col space-y-2">
                <label for="default_ports" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Default Ports</span>
                </label>
                <input type="text" id="default_ports" name="default_ports"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('default_ports') ?? $ports }}" required placeholder="25565">
            </div>

            <!-- Default Databases -->
            <div class="flex flex-col space-y-2">
                <label for="default_databases" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Default Databases</span>
                </label>
                <input type="text" id="default_databases" name="default_databases"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('default_databases') ?? $databases }}" required placeholder="MySQL">
            </div>

            <!-- Default Backups -->
            <div class="flex flex-col space-y-2">
                <label for="default_backups" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Default Backups</span>
                </label>
                <input type="text" id="default_backups" name="default_backups"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('default_backups') ?? $backups }}" placeholder="e.g., daily">
            </div>
            <div class="flex flex-col space-y-2">
                <label for="renewal" class="text-lg font-medium text-gray-300 flex items-center space-x-2">
                    <span>Renewal Cost For Servers</span>
                </label>
                <input type="text" id="renewal" name="renewal"
                    class="bg-black text-white border-global rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    value="{{ old('renewal') ?? $backups }}" placeholder="e.g., 4$ ( credits ofc )">
            </div>

            <!-- Submit Button -->
            <div class="flex">
                <button type="submit"
                    class="bg-blue-800 text-white font-semibold rounded w-full py-3 hover:bg-blue-800 transition-colors">
                    Save Changes <i class="fa-solid fa-pen-to-square"></i>
                </button>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const editButton = document.getElementById('edit-resources-btn');
            const formContainer = document.getElementById('resources-form');

            editButton.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent default anchor behavior
                formContainer.classList.toggle('hidden');
            });
        });
    </script>
    <script>
        const sidebarLinks = [{
                title: 'Overview',
                icon: 'fa-desktop',
                url: '#',
                active: true,
            },
            {
                title: 'Users',
                icon: 'fa-users',
                url: 'users',
            },
            {
                title: 'Products',
                icon: 'fa-box',
                url: 'products',
            },
            {
                title: 'Settings',
                icon: 'fa-gear',
                url: 'settings',
                hasDivider: true,
            },
            {
                title: 'Servers',
                icon: 'fa-server',
                url: '{{ route('admin.servers') }}',
            },
            {
            title: 'Images',
            icon: 'fa-egg',
            url: '{{ route('admin.eggs') }}',
        },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);
    </script>
@endsection
