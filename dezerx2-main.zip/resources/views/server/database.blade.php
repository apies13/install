@extends('server.layouts.app')

@section('title', 'Databases')

@section('content')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
    .console-container {
        background: rgb(13, 22, 33);
        background: -moz-linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
        background: -webkit-linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
        background: linear-gradient(328deg, rgba(13, 22, 33, 1) 71%, rgba(21, 29, 77, 0.4654236694677871) 100%, rgba(30, 38, 131, 0.5970763305322129) 100%, rgba(18, 19, 19, 1) 100%, rgba(6, 122, 150, 1) 100%, rgba(13, 22, 33, 0.3253676470588235) 100%);
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#0d1621", endColorstr="#0d1621", GradientType=1);
    }

    ::-webkit-scrollbar {
        width: 3px;
    }

    ::-webkit-scrollbar-track {
        background: black;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: #0f0f11;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: #0f0f11;
    }

    .bg-cards {
            background-color: #0c0c0c;
            border: 1px solid #1d1d1d72;

        }
    .bg-icon {
        background-color: #0f0f11;
        box-shadow: 0px 0px 4px #000;
        border: 1px solid #1d1d1d;
    }

    .border-devider {
        border-color: #1d1d1d;
    }

    .border-global {
        border: 1px solid #1d1d1d;
    }

    .bg-url {
        background-color: #171719;
        border: 1px solid #1d1d1d;
    }

    .w-custom {
        width: fit-content;
    }

    /* Mobile-specific styles */
    @media (max-width: 640px) {
        .hid {
            display: none;
        }
    }

    .dark-mode-popup {
        background-color: rgb(13, 22, 33) !important;
        color: white !important;
    }

    .dark-mode-title {
        color: white !important;
    }

    .dark-mode-content {
        color: white !important;
    }

    .h-custom {
        height: 27rem;
    }

    .bg-icons {
        background-color: #0c0c0e;
    }



    .header {
        position: relative;
        background-image: url("https://wallpaperaccess.com/full/2984692.jpg");
        background-size: cover;
        background-position: center;
        height: 200px;
        color: white;
    }

    .header::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(to bottom, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 1));
        z-index: 1;
    }

    .header>* {
        position: relative;
        z-index: 2;
    }
</style>

<aside id="logo-sidebar"
    class="fixed top-0 left-0 z-40 w-64 h-screen pt-20 transition-transform -translate-x-full bg-sidebar border-sidebar sm:translate-x-0"
    aria-label="Sidebar">
    <div class="h-full px-3 pb-4 overflow-y-auto bg-sidebar">
        <ul id="sidebar-links" class="space-y-2 font-medium">
        </ul>
    </div>
</aside>

<div class="container mt-2">
    <div class="flex items-center mb-4">

        <div class=" flex space-x-2">
            <form action="{{ route('database.create', $identifier) }}" method="POST">
                @csrf
                <button type="submit"
                    class="bg-green-700 text-white px-3 font-bold py-2 rounded border border-green-800">
                    <i class="fa-solid fa-plus"></i> Create Database
                </button>
            </form>
        </div>
    </div>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-cards text-gray-300  rounded-lg">
            <thead class="text-left bg-cards">
                <tr>
                    <th class="py-2 text-sm font-semibold px-4">Host</th>
                    <th class="py-2 text-sm font-semibold px-4">Port</th>
                    <th class="py-2 text-sm font-semibold px-4">Name</th>
                    <th class="py-2 text-sm font-semibold px-4">Username</th>
                    <th class="py-2 text-sm font-semibold px-4">Password</th>
                    <th class="py-2 text-sm font-semibold px-4">Connections From</th>
                    <th class="py-2 text-sm font-semibold px-4">Max Connections</th>
                </tr>
            </thead>
            <tbody>
                @forelse($databases as $database)
                    <tr>
                        <td class="py-2 px-4">{{ $database['host'] }}</td>
                        <td class="py-2 px-4">{{ $database['port'] }}</td>
                        <td class="py-2 px-4">{{ $database['name'] }}</td>
                        <td class="py-2 px-4">{{ $database['username'] }}</td>
                        <td class="py-2 px-4 relative">
                            <span class="password-blur ">{{ $database['password'] }}</span>
                        </td>
                        <style>

                        </style>
                        <td class="py-2 px-4">{{ $database['connections_from'] }}</td>
                        <td class="py-2 px-4">{{ $database['max_connections'] }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="py-2 px-4 text-center text-gray-500">No databases available</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="footer items-center bottom-0 w-full text-gray-400 py-4 mt-4">
  <div class="text-center">
    <h1 class="text-sm">
      Made with <i class="fa-solid text-red-700 fa-heart"></i> by
      <a class="underline text-blue-600" href="https://anthonys.pro">Anthony S</a>
    </h1>
  </div>
</div>


    <script>
        function toggleDropdown(event) {
            const clickedIcon = event.target;
            const menu = clickedIcon.nextElementSibling;

            document.querySelectorAll('.dropdown-menu').forEach(m => {
                if (m !== menu) m.classList.add('hidden');
            });

            menu.classList.toggle('hidden');

            event.stopPropagation();
        }

        document.addEventListener('click', (event) => {
            if (!event.target.closest('.dropdown-menu') && !event.target.closest('.fa-ellipsis')) {
                document.querySelectorAll('.dropdown-menu').forEach(menu => {
                    menu.classList.add('hidden');
                });
            }
        });
    </script>


    <script>
        const sidebarLinks = [
            {
                title: 'Console',
                icon: 'fa-code',
                url: 'console',
                active: false,
            },
            {
                title: 'File Manager',
                icon: 'fa-folder',
                url: 'file-manager',
                active: false,
            },
            {
                title: 'Plugin Manager',
                icon: 'fa-box',
                url: 'plugins',
                hasDivider: false,

            },
            {
                title: 'Backups',
                icon: 'fa-download',
                url: 'backups',
                active: false,

            },
            {
                title: 'Databases',
                icon: 'fa-database',
                url: 'database',
                active: true,

            },
            {
                title: 'Network',
                icon: 'fa-network-wired',
                url: 'network',
            },
            {
                title: 'Settings',
                icon: 'fa-gears',
                url: 'settings',
            },
        ];

        function generateSidebarLinks() {
            const sidebarLinksContainer = document.getElementById('sidebar-links');
            sidebarLinks.forEach(link => {
                const listItem = document.createElement('li');
                const activeClass = link.active ? 'bg-url' : '';

                listItem.innerHTML = `
            <a href="${link.url}" class="flex items-center p-2 text-gray-900 rounded-lg dark:text-white group transform transition-transform hover:scale-105 ${activeClass}">
                <i class="fa-solid fa-lg text-gray-300 ${link.icon}"></i>
                <span class="flex-1 ms-3 whitespace-nowrap">${link.title}</span>
            </a>
        `;

                sidebarLinksContainer.appendChild(listItem);
                if (link.hasDivider) {
                    const divider = document.createElement('div');
                    divider.classList.add('border-custom');
                    sidebarLinksContainer.appendChild(divider);
                }
            });
        }

        document.addEventListener('DOMContentLoaded', generateSidebarLinks);

    </script>

    @endsection
